package com.example.dmitry.rts;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;


import java.util.Arrays;

/**
 * Created by Dmitry on 02.04.2016.
 */
public class MapEditor extends Activity implements SeekBar.OnSeekBarChangeListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_editor);

        w = (TextView)findViewById(R.id.textViewW);
        h = (TextView) findViewById(R.id.textViewH);
        sw = (SeekBar) findViewById(R.id.seekBarWidth);
        sh = (SeekBar) findViewById(R.id.seekBarHeight);
        sw.setOnSeekBarChangeListener(this);
        sh.setOnSeekBarChangeListener(this);

    }
    TextView w;
    TextView h;
    SeekBar sw,sh;
    public static int W;
    public static int H;
    int tw,th;

    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
        if (seekBar.equals(sw)){ w.setText(i+""); tw=i;}
        if (seekBar.equals(sh)) {h.setText(i+""); th=i;}
        Log.d("OnProgress",tw+" "+th);
    }


    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
    static MyView myView;
    public void start(View v){
        W=tw;
        H=th;
        setContentView(R.layout.activity_surface);

        findViewById(R.id.pause).setVisibility(View.INVISIBLE);
        findViewById(R.id.rotate).setVisibility(View.INVISIBLE);
        findViewById(R.id.formation).setVisibility(View.INVISIBLE);
        findViewById(R.id.super_power).setVisibility(View.INVISIBLE);
        findViewById(R.id.build_aim).setVisibility(View.INVISIBLE);
        findViewById(R.id.save).setOnClickListener((AdapterView.OnClickListener)findViewById(R.id.surfaceView));

        ListView listView = (ListView) findViewById(R.id.squad_list);
        MyAdapter adapterS = new MyAdapter(this, R.layout.my_list_layout, R.id.myListText, Arrays.asList(getResources().getStringArray(R.array.maps)),2,getLayoutInflater());
        listView.setAdapter(adapterS);
        listView.setOnItemClickListener((AdapterView.OnItemClickListener)(findViewById(R.id.surfaceView)));
        myView.setAdapter(adapterS);

        Spinner spinner = (Spinner)findViewById(R.id.spinner);
        ArrayAdapter<?> adapter = ArrayAdapter.createFromResource(this, R.array.menu, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) (findViewById(R.id.surfaceView)));
        SeekBar seekBar = (SeekBar)findViewById(R.id.seekBar);
        seekBar.setLeft(10);
        seekBar.setRight(300);
        seekBar.setMax(18); // <- dont really need this
        seekBar.setProgress(13);
        seekBar.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener) (findViewById(R.id.surfaceView)));
    }
}

