package com.example.dmitry.rts.Behaviors.PathSearch;

import android.util.Log;

import com.example.dmitry.rts.Objects.Tiles.Tile;
import com.example.dmitry.rts.Objects.Tiles.Water;
import com.example.dmitry.rts.Point;
import com.example.dmitry.rts.MyMap;
import com.example.dmitry.rts.Rectangle;

import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

/**
 * Created by Dmitry on 01.01.2016.
 */
public class Search {
    ArrayList<Point> route;
    MyMap myMap;
    int counter=-1;
    int w,h;
    int tile;
    double diag;
     double[][] MAP;


    public Search(MyMap myMap){
        this.myMap = myMap;
        w=myMap.getW()-1;
        h=myMap.getH()-1;
        tile = myMap.getTILE_SIZE();

        diag = Math.round(tile*1.44f);
        diag = 1.5;
        Log.d("Search","new Search myMap "+this.myMap+"  w "+w+"  h "+h+"  tile "+tile+" diag "+diag);
        MAP = new double[w][h];
    }
    public Point getNextPoint(){
        counter--;
        if (counter==0) {Log.d("Search", " Search nextPoint returning " + -way.get(counter).getX() + " " + -way.get(counter).getY() + " counter=" + counter);
            return way.get(counter).multipy(-1);}
        try {
         Log.d("Search"," Search nextPoint returning "+way.get(counter).getX()+" "+way.get(counter).getY()+" counter="+counter);  return way.get(counter); } catch (Exception e){Log.d("Search", "Search " + e + " counter: " + counter);
           return new Point(0,0); }
       }


    int[] dx = { -1,-1, 1, 1, 1,-1, 0, 0};
    int[] dy = { -1, 1,-1, 1, 0, 0, -1, 1};
    double[][] map;
    boolean done;
    boolean noway;
    ArrayList<Point> way;

    void updateMAP(){
      /*  for (int i=0; i<w; i++)
            for (int j=0; j<h; j++)
                if (myMap.isEngaged(i,j)) MAP[i][j]=-2; else MAP[i][j]=-1; //-2 wall -1 free*/

        for (int i=0; i<w; i+=2)
            for (int j=0; j<h; j+=2)

                if (myMap.isEngaged(i,j)||myMap.isEngaged(i+1,j)||myMap.isEngaged(i,j+1)||myMap.isEngaged(i+1,j+1)) MAP[i/2][j/2]=-2; else MAP[i/2][j/2]=-1;

    }



    public int getTileSize(){return tile;}


 public void findWay(int x0, int y0,int x1, int y1, Rectangle rect){
     manual=false;
     for (int i=0; i<200; i++)
         for (int j=0; j<200; j++)
             myMap.inSearch[i][j]=false;
    // System.gc();
     int side = rect.getWidth()/tile;
     Log.d("Log","Search searching way "+x0+" "+y0+" to "+x1+" "+y1);
     /*for (int i=0; i<120; i++)
         for (int j=0; j<120; j++) myMap.inSearch[i][j]=false;*/

             counter = -1;
      done=noway=false;
     int d=0;
     int spaceCounter=0;
     map = new double[myMap.getW()][myMap.getH()];
      way = new ArrayList<>();
    // if (rect.getHeight()>tile||rect.getWidth()>tile) tile = Math.max(rect.getWidth(),rect.getHeight());
      int x=x0/tile;
      int y=y0/tile;
      x1 /=tile;
      y1 /=tile;
     if (x1<0) x1=0; else if (x1>w) x1=w;
     if (y1<0) y1=0; else if (y1>h) y1=h;
     if (x==x1&&y==y1) {way.add(new Point(-x1*tile, -y1*tile)); return;}
     if (myMap.shouldUpdate) updateMAP();
     map = MAP.clone();

     x/=2; y/=2; x1/=2; y1/=2;
     map[x][y]=d;
     map[x1][y1]=-1;

   /*  StringBuilder s1 = new StringBuilder();
     for (int j=0; j<h; j++) {

         for (int i = 0; i < w; i++) {
             if (map[i][j] > -1 && map[i][j] < 10) s1.append(" ");
             s1.append(map[i][j]);
         }
         Log.d("Search", s1.toString());
         s1 = new StringBuilder();

     }*/
     Log.d("Search","map filled");

     Log.d("Search"," x1 y1 "+x1+" "+y1+" map "+map[x1][y1]);
     int time=0;


     while (!done) {
         time++;

/*
         for (int i = Math.max(x - d,0); i <=Math.min(x + d,w); i++) {

                try{ if (map[i][y-d]>-1) {

                         try {
                            // Log.d("Search", "working.. "+i + dx[k]+" "+(y + dy[k]- d ));
                             if ( map[i + dx[0]][y + dy[0]- d ] == -1 || map[i + dx[0]][y + dy[0]- d ]>map[i][y-d]+diag )  map[i + dx[0]][y + dy[0] -d ] = map[i][y-d]+diag;
                         } catch (ArrayIndexOutOfBoundsException e) {
                             Log.d("Search", "working.. " + e);
                         }
                    try {
                        // Log.d("Search", "working.. "+i + dx[k]+" "+(y + dy[k]- d ));
                        if (map[i + dx[2]][y + dy[2]- d ] == -1||map[i + dx[2]][y + dy[2]- d ]>map[i][y-d]+diag)  map[i + dx[2]][y + dy[2] -d ] = map[i][y-d]+diag;
                    } catch (ArrayIndexOutOfBoundsException e) {
                        Log.d("Search", "working.. " + e);
                    }

                 } } catch (ArrayIndexOutOfBoundsException e) {}

                try{ if (map[i][y+d]>-1) {

                         try {//Log.d("Search", "working.. "+i + dx[k]+" "+(y + dy[k]+ d ));
                             if (map[i + dx[1]][y + dy[1] +d ] == -1 ||map[i + dx[1]][y + dy[1] +d ]>map[i][y+d]+diag )  map[i + dx[1]][y + dy[1] + d] = map[i][y+d]+diag;
                         } catch (ArrayIndexOutOfBoundsException e) {
                             Log.d("Search", "working.. " + e);
                         }
                    try {//Log.d("Search", "working.. "+i + dx[k]+" "+(y + dy[k]+ d ));
                        if (map[i + dx[3]][y + dy[3] +d ] == -1|| map[i + dx[3]][y + dy[3] +d ]>map[i][y+d]+diag)  map[i + dx[3]][y + dy[3] + d] = map[i][y+d] + diag;
                    } catch (ArrayIndexOutOfBoundsException e) {
                        Log.d("Search", "working.. " + e);
                    }

                 } }catch (ArrayIndexOutOfBoundsException e){ Log.d("Search", "working.. " + e);}
     } //1.1

         for (int j =Math.max(y - d,0); j <=Math.min(y + d,h); j++) {

             try {
                 if (map[x-d][j]>-1)
                  {
                     for (int k = 0; k < 2; k++) {
                         try {//Log.d("Search", "working.. "+(x + dx[k] -d )+ " "+(j + dy[k]));
                             if (map[x + dx[k] -d ][j + dy[k]] == -1||map[x + dx[k] -d ][j + dy[k]]>map[x-d][j]+diag) map[x + dx[k] - d][j + dy[k]] = map[x-d][j] + diag;
                         } catch (ArrayIndexOutOfBoundsException e) {
                             Log.d("Search", "working.. " + e);
                         }
                     }
                 }
             } catch (ArrayIndexOutOfBoundsException e) {
             }

             try {
                 if (map[x+d][j]>-1)
                  {
                     for (int k = 2; k < 4; k++) {
                         try {//Log.d("Search", "working.. "+(x + dx[k] +d )+ " "+(j + dy[k]));
                             if (map[x + dx[k] + d][j + dy[k]] == -1|| map[x + dx[k] + d][j + dy[k]]>map[x+d][j]+diag) map[x + dx[k] + d][j + dy[k]] = map[x+d][j]+diag;
                         } catch (ArrayIndexOutOfBoundsException e) {
                             Log.d("Search", "working.. " + e);
                         }
                     }
                 }
             } catch (ArrayIndexOutOfBoundsException e) {
             }
         } //1.2


         for (int i = Math.max(x - d,0); i <=Math.min(x + d,w); i++) {

             try{  if (map[i][y-d]>-1) {
                     try {
                         // Log.d("Search", "working.. "+i + dx[k]+" "+(y + dy[k]- d ));
                         if (map[i + dx[6]][y + dy[6]- d ] == -1||map[i + dx[6]][y + dy[6]- d ]>d+1)  map[i + dx[6]][y + dy[6] -d ] = map[i][y-d] +1;
                     } catch (ArrayIndexOutOfBoundsException e) {
                         Log.d("Search", "working.. " + e);
                     }

             } } catch (ArrayIndexOutOfBoundsException e) {}

             try{
                 if (map[i][y+d]>-1) {
                     try {//Log.d("Search", "working.. "+i + dx[k]+" "+(y + dy[k]+ d ));
                         if (map[i + dx[7]][y + dy[7] +d ] == -1|| map[i + dx[7]][y + dy[7] +d ] > d+1)  map[i + dx[7]][y + dy[7] + d] = map[i][y+d] +1;
                     } catch (ArrayIndexOutOfBoundsException e) {
                         Log.d("Search", "working.. " + e);

                 }
             } }catch (ArrayIndexOutOfBoundsException e){ Log.d("Search", "working.. " + e);}
         } //2.1

         for (int j =Math.max(y - d,0); j <=Math.min(y + d,h); j++) {

             try {
                 if (map[x-d][j]>-1)
                  {
                         try {//Log.d("Search", "working.. "+(x + dx[k] -d )+ " "+(j + dy[k]));
                             if (map[x + dx[5] -d ][j + dy[5]] == -1|| map[x + dx[5] -d ][j + dy[5]] >d+1) map[x + dx[5] - d][j + dy[5]] = map[x-d][j]+1;
                         } catch (ArrayIndexOutOfBoundsException e) {
                             Log.d("Search", "working.. " + e);

                     }
                 }
             } catch (ArrayIndexOutOfBoundsException e) {
             }

             try {
                 if (map[x+d][j]>-1)
                  {
                         try {//Log.d("Search", "working.. "+(x + dx[k] +d )+ " "+(j + dy[k]));
                             if (map[x + dx[4] + d][j + dy[4]] == -1|| map[x + dx[4] + d][j + dy[4]] > d+1) map[x + dx[4] + d][j + dy[4]] = map[x+d][j]+1
                                     ;
                         } catch (ArrayIndexOutOfBoundsException e) {
                             Log.d("Search", "working.. " + e);
                         }

                 }
             } catch (ArrayIndexOutOfBoundsException e) {
             }
         } //2.2*/




         for (int i = Math.max(x - d,0); i <= Math.min(x + d,w/2-1); i++)
             for (int j =Math.max(0,y - d); j <=Math.min(y + d,h/2-1); j++){

                 if (Math.round(map[i][j]) == d) {
                     for (int k = 0; k < 8; k++) {
                         try {
                             if (map[i + dx[k]][j + dy[k]] >d+1||map[i + dx[k]][j + dy[k]]==-1)
                                 map[i + dx[k]][j + dy[k]] += d + 2.0;
                         } catch (ArrayIndexOutOfBoundsException e) {
                             Log.d("Search", "working.. " + e);
                         }
                     }
                 }
             }



         if (map[x1][y1]>-1) done = true;
        // Log.d("Search"," analyzing..."+time+" "+x1+" "+y1+" map "+map[x1][y1]);
         if (d>Math.max(w,h)) break;
         d++;
       //  Log.d("Search","               ");
     }


     Log.d("Search","time ="+time+" done "+done);

     /*StringBuilder s = new StringBuilder();
     for (int j=0; j<h; j++) {
     for (int i=0; i<w; i++){
         if (map[i][j]>-1&&map[i][j]<10) s.append(" ");
        // if (map[i][j]>=10&&map[i][j]<1000) s.append(" ");
             s.append(map[i][j]);
         }
         Log.d("Search",s.toString());
         s=new StringBuilder();

         }*/

     done=!done;
    /* for (int i = Math.max(x - d-8,0); i <= Math.min(x + d+8,w); i++)
         for (int j =Math.max(0,y - d-8); j <=Math.min(y + d+8,h); j++){
           //  try{ if (map[i][j]>-1) if (map[i+2][j]<-1||map[i][j+2]<-1||map[i+2][j+2]<-1) map[i][j]+=0.1;} catch (ArrayIndexOutOfBoundsException e){}
            try{ if (map[i][j]>-1) if (map[i+1][j]<-1||map[i][j+1]<-1||map[i+1][j+1]<-1) map[i][j]+=0.1;} catch (ArrayIndexOutOfBoundsException e){}
         }*/
     //x=x1;
     //y=y1;
     int tx=0, ty=0; //temp x,y
     double min;
     Log.d("Search", "making array...");
     way.add(new Point(x1*2 * tile, y1*2 * tile));
    // myMap.inSearch[x1][y1]=true;

     if (!done)
     while (map[x1][y1]!=1&&map[x1][y1]!=1.5&&map[x1][y1]!=0){
          min=999;
         for (int k=0; k<8; k++){
             try{ if (map[ x1+dx[k] ][ y1+dy[k] ]>=0)
                 if(map[ x1+dx[k] ][ y1+dy[k] ]<=min) {
                 min=map[x1+dx[k]][y1+dy[k]]; tx=x1+dx[k]; ty=y1+dy[k];}

             } catch (ArrayIndexOutOfBoundsException e){ Log.d("Sea", "exc "+e);}
         }

         x1=tx; y1=ty;
       //  if (map[x1][y1-1]==-2&&map[x1][y1]==-1&&map[x1][y1+1]==-1)
            // way.add(new Point(x1*2*tile+tile/2, y1*2*tile+tile/2));
         way.add(new Point(x1*2*tile+tile, y1*2*tile+tile));
         myMap.inSearch[x1*2][y1*2]=true;
         myMap.inSearch[x1*2+1][y1*2]=true;
         myMap.inSearch[x1*2][y1*2+1]=true;
         myMap.inSearch[x1*2+1][y1*2+1]=true;
         Log.d("Sea", "new point " + x1 + " " + y1 + "  " + map[x1][y1]);
         if (way.size()>w*h) map[x1][y1]=1;
     }
     counter=way.size();
     Log.d("Search","ready:");
     //for (int i=0; i<way.size(); i++){Log.d("Search","way: "+i+" "+way.get(i).getX()+" "+way.get(i).getY());}
    }

    boolean manual=false;
    public void addWayPoint(int x, int y){
        if (!manual) {
            manual = true;
            way=new ArrayList<>();
        }
        way.add(new Point(x*2*tile,y*2*tile));
        myMap.inSearch[x*2][y*2]=true;
        myMap.inSearch[x*2+1][y*2]=true;
        myMap.inSearch[x*2][y*2+1]=true;
        myMap.inSearch[x*2+1][y*2+1]=true;

    }
    public void resetCounter(){
        counter=way.size();
        String s="";
        for (int i=counter-1; i>-1; i--)
            s+=" "+way.get(i).getX()+":"+way.get(i).getY();
        Log.d("Search","PavedWay:"+s);
    }

}
