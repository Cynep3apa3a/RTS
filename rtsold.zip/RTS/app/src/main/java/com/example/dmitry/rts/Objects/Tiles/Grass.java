package com.example.dmitry.rts.Objects.Tiles;

import com.example.dmitry.rts.MyMap;

/**
 * Created by Dmitry on 20.02.2016.
 */
public class Grass extends Tile {
    public Grass(int x, int y, MyMap myMap) {
        super(x, y, myMap);
        speedBonus=0;
        defenceBonus=1;
    }
}
