package com.example.dmitry.rts.Objects.Buildings;



import com.example.dmitry.rts.MyMap;
import com.example.dmitry.rts.Rectangle;

import java.util.Arrays;

/**
 * Created by Dmitry on 03.03.2016.
 */
public class Portal extends Building{
    public Portal(int x, int y, int team) {
        super(x, y, team);
        h=60;
        w=60;
        hp=100;
        rect=new Rectangle(x,y,x+w,y+h);
    }
    @Override
    public void setMap(MyMap map){this.myMap=map;
        engaged = new boolean[w/myMap.getTILE_SIZE()*h/myMap.getTILE_SIZE()];
        Arrays.fill(engaged, true);}




    public void setFront(char front){
        switch (front){
            case 'u': { for (int i=6; i<30; i++) engaged[i]=false;}
            break;
            case 'd': { for (int i=6; i<30; i++) engaged[i]=false;}
            break;
            case 'l': {
                for (int j=1; j<5; j++)
                for (int i=0; i<=30; i+=6) engaged[i+j]=false;}
            break;
            case 'r': { for (int j=1; j<5; j++)
                for (int i=0; i<30; i+=6) engaged[i+j]=false;}
            break;



        }

name+=front;
    }


}
