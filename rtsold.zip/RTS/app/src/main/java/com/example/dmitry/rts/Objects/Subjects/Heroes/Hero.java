package com.example.dmitry.rts.Objects.Subjects.Heroes;

import com.example.dmitry.rts.MyMap;
import com.example.dmitry.rts.Objects.Subjects.Subject;

/**
 * Created by Dmitry on 24.01.2016.
 */
public class Hero extends Subject {
    public Hero(int id,MyMap myMap) {
        super(id,myMap);
        vel=2;
        w=20;
        h=20;
        HP=hp=5;
    }
}
