package com.example.dmitry.rts;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;



public class MainActivity extends Activity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

    setContentView(R.layout.activity_main);

        //(findViewById(R.id.openMap)).setOnClickListener(openMap());
      //  (findViewById(R.id.settings)).setOnClickListener(this);
       // (findViewById(R.id.exit)).setOnClickListener(this);





    }
    public void openMap(View view){
        Intent intent = new Intent(this,MapChoose.class);
        startActivity(intent);
    }
    public void viewSettings(View view){
        Intent intent = new Intent(this,Settings.class);
        startActivity(intent);
    }
    public void exit(View view){ System.exit(0);}

    public void editor(View view){
        Intent intent = new Intent(this,MapEditor.class);
        startActivity(intent);
    }
    public void load(View view){

        Intent intent = new Intent(this,Load.class);
        startActivity(intent);

    }



public static int quan ;
    public static String sub;
    public static String map="Maps/def";




}
