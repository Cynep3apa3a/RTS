package com.example.dmitry.rts.Objects.Tiles;

import com.example.dmitry.rts.MyMap;

/**
 * Created by Dmitry on 25.02.2016.
 */
public class Road extends Tile {
    public Road(int x, int y, MyMap myMap) {
        super(x, y, myMap);
        speedBonus=1;
        defenceBonus=1;
    }
}
