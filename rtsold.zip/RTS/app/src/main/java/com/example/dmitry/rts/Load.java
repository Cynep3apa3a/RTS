package com.example.dmitry.rts;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Spinner;

import java.util.Arrays;

/**
 * Created by Dmitry on 09.04.2016.
 */
public class Load extends MapChoose implements AdapterView.OnItemClickListener{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        requestWindowFeature(Window.FEATURE_NO_TITLE);
        // MyView myView = new MyView(this);
        //   setContentView(myView);
        setContentView(R.layout.activity_maps);
        ListView listView = (ListView) findViewById(R.id.listView);
        MyAdapter adapter = new MyAdapter(this, R.layout.my_list_layout, R.id.myListText, Arrays.asList(getResources().getStringArray(R.array.maps)) ,1,getLayoutInflater());
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);

        //  buttons = (ListView)findViewById(R.id.squadsList);
        layout = (FrameLayout)findViewById(R.id.activity_surface);
    }
}
