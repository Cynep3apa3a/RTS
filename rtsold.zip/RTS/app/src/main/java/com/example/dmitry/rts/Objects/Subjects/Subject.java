package com.example.dmitry.rts.Objects.Subjects;

import android.graphics.Bitmap;
import android.util.Log;

import com.example.dmitry.rts.Behaviors.PathSearch.Search;
import com.example.dmitry.rts.Decoder;
import com.example.dmitry.rts.MainActivity;
import com.example.dmitry.rts.MyMap;
import com.example.dmitry.rts.Objects.Buildings.Building;
import com.example.dmitry.rts.Point;
import com.example.dmitry.rts.Rectangle;
import com.example.dmitry.rts.Renderer;

import java.io.Serializable;

/**
 * Created by Dmitry on 16.01.2016.
 */
public class Subject implements Serializable{
    protected transient Point position;
    protected transient Point absolutePos;

    protected transient Rectangle rect;
   protected int w;
   protected int h;
   protected int vel;
    protected int atcDist;
    protected int atc;
    protected int HP; //hp
    protected int hp; //remaining hp

    protected int speedBonus =0;
    int id;
    protected boolean attacking =false;

    protected Squad mySquad;
    int team;
    protected double radius;
    transient protected MyMap myMap;
    Search search;
    int tx;
    int ty;
    double xc;
    double yc;
    protected double alpha = 0; //angle
    protected double turnAng=0; //turn angle
    boolean shouldGo=true;

    transient protected Point tempTarget;
    int targetX,targetY;
    int tile;
    String name;
    boolean enemyNearby=false;

    public Subject(int id, MyMap myMap){
        this.id=id;
        this.myMap = myMap;
        search = new Search(myMap);
        setName();

    }
    public String getName(){ return name;}
    public void setSquad(Squad squad){mySquad=squad;}
    public Rectangle getRect(){ return rect;}
    int a;
    int pitch=1;
    Subject enemy;

    public void update(Renderer renderer, int time){

        if (hp<=0) {mySquad.destroyMe(this); return;}
        if (enemyNearby&&reloading>=reload){  //fixit
            if ((enemy=myMap.getTile(rect.getCenterX()/tile-1,rect.getCenterY()/tile-1).isEnemy(team))!=null)
            {
                if (attack(enemy)) return;}
            if ((enemy=myMap.getTile(rect.getCenterX()/tile-1,rect.getCenterY()/tile).isEnemy(team))!=null)
            {if (attack(enemy)) return;}
            if ((enemy=myMap.getTile(rect.getCenterX()/tile-1,rect.getCenterY()/tile+1).isEnemy(team))!=null)
            {if (attack(enemy)) return;}
            if ((enemy=myMap.getTile(rect.getCenterX()/tile,rect.getCenterY()/tile-1).isEnemy(team))!=null)
            {if (attack(enemy)) return;}
            if ((enemy=myMap.getTile(rect.getCenterX()/tile,rect.getCenterY()/tile+1).isEnemy(team))!=null)
            {if (attack(enemy)) return;}
            if ((enemy=myMap.getTile(rect.getCenterX()/tile+1,rect.getCenterY()/tile-1).isEnemy(team))!=null)
            {if (attack(enemy)) return;}
            if ((enemy=myMap.getTile(rect.getCenterX()/tile+1,rect.getCenterY()/tile).isEnemy(team))!=null)
            {if (attack(enemy)) return;}
            if ((enemy=myMap.getTile(rect.getCenterX()/tile+1,rect.getCenterY()/tile+1).isEnemy(team))!=null)
            {if (attack(enemy)) return;}
        }
        if (reloading<reload) reloading++;
        myMap.exclude(this);
    go(renderer);
        myMap.setTaken(this);

}
int orderedAlpha=0;
    public void draw(Renderer renderer) {
        if (hp<=0) return;

        a = (int) (Math.toDegrees(Math.atan2(ty, tx)));
        if (tx==0&&ty==0) a=orderedAlpha;

        renderer.drawHpOval(rect, HP, hp);


      if (attacking) {renderer.drawImg(name+"a", rect, a, 0); attacking=false;}else  renderer.drawImg(name, rect, a, pitch/6);
        if (usingSearch) renderer.drawText("s",rect.getCenterX(),rect.getCenterY());

      //  renderer.drawText(hp+"",rect.getX(),rect.getY()+10,0xFF2222FF);
    }

     public void setName(){ name =  "Subjects/" + getClass().getSimpleName().toLowerCase();}

    boolean attack(Subject subject){
        if (subject.getRect().pif(rect.getCenterX(),rect.getCenterY())<(atcDist+w/2+h/2)*(atcDist+w/2+h/2))
        {
            subject.looseHp(atc);
            reloading=0;
            attacking=true;
            return true;

        }
        attacking = false;
        return false;
    }

    protected int reload=30;
    private int reloading=30;


    public void setTeam(int team){this.team = team;}

    public int getTeam(){ return team;}

    public void setRect(int x, int y){
        rect = new Rectangle(x-w/2,y-w/2,x+w/2+w%2,y+h/2+h%2);
        tile = myMap.getTILE_SIZE();

    }

    public void setPos(Point pos){ position=pos; alpha = (Math.atan2(pos.getY(),pos.getX())); radius=Math.sqrt(pos.getX()*pos.getX()+pos.getY()*pos.getY()); } //squad position

    public void setAbsolutePos(Point absolutePos){/*speedBonus=vel;*/ this.absolutePos=absolutePos;}

    public Point getAbsolutePos(){  return absolutePos;}


    public Point getPos(){return position;}

    public Point getCoordinates(){return new Point(rect.getCenterX(),rect.getCenterY());}

    public void looseHp(int hp){this.hp-=hp;
    Log.d("Subject","I am attacked! lost "+hp+" got "+this.hp+"/"+HP);}


    void findWay(){
        if (mySquad.targetBuilding==null){
        search.findWay(rect.getX() + w / 2, rect.getY() + h / 2, targetX, targetY,rect);}
        else{
            search.findWay(rect.getX() + w / 2, rect.getY() + h / 2, mySquad.targetBuilding.getMinX(rect.getCenterX()), mySquad.targetBuilding.getMinY(rect.getCenterY()),rect);
    }
        shouldGo=true;
    }
    void findWay(int x, int y){ //for difficult situations
        search.findWay(x + w / 2, y + h / 2, targetX, targetY,rect);
        shouldGo=true;
    }
    public void setTarget(int x, int y){

        targetX=x+position.getX()*w; targetY=y+position.getY()*h;

        findWay();
        askNextPoint();
    }

public int getId(){return id;}
    public int getSquadId(){return mySquad.getId();}
    public Squad getSquad(){return mySquad;}

    void turn(int ang){this.turnAng+=(ang*0.0174533); this.turnAng%=6.2831;}
    void turnEach(int ang){
        orderedAlpha=ang;
    }
    void turnEachPlus(int ang){
        orderedAlpha+=ang;
    }


    boolean usingSearch = false;
    int standing=0;

    public void go(Renderer renderer){
        speedBonus=mySquad.getCommanderSpeedBonus();
        if (usingSearch)  {goSearch(renderer); return;}

         tx=0;
        ty=0;

         xc = Math.round(mySquad.commanderCoordinates.getX()+w*Math.cos(alpha + turnAng) *radius);
        yc = Math.round(mySquad.commanderCoordinates.getY() + h*Math.sin(alpha + turnAng) *radius);
        if (rect.getCenterX()<xc) tx=1; else if (rect.getCenterX()>xc) tx=-1;
        if (rect.getCenterY()<yc) ty=1; else if (rect.getCenterY()>yc) ty = -1;
        if (Math.abs(rect.getCenterX() - xc)<(vel+speedBonus)) tx*=Math.abs(rect.getCenterX() - xc)/(vel+speedBonus);
        if (Math.abs(rect.getCenterY()-yc)<(vel+speedBonus)) ty*=Math.abs(rect.getCenterY() - yc)/(vel+speedBonus);
        tx*=(vel+speedBonus);
        ty*=(vel+speedBonus);
        if (tx!=0||ty!=0){
            pitch++;
            if (pitch>9) pitch=1;
            Point movingPoint = renderer.move(rect, tx, ty);

            if (movingPoint.getX()==0&&movingPoint.getY()==0)
                standing++;
             if (standing>10) {
                 if (!usingSearch)superPowerActivate();
             if (standing>50){ superPowerDeactivate();standing=0;}
             }

        rect.move(tx*movingPoint.getX(),ty*movingPoint.getY());
           // myMap.setTaken(this);
            Log.d("Mov", "sub move "+ tx*movingPoint.getX()+" "+ty*movingPoint.getY());
        } else pitch=0;

    }
    public void superPowerActivate(){
        Log.d("Subject","super power activated!");
        Log.d("Subject"," mySquad targets "+targetX+" "+targetY);
        //tempTarget = new Point(rect.getCenterX(),rect.getY());
        //targetX=mySquad.targetX+position.getX()*w;
        //targetY=mySquad.targetY+position.getY()*h;
        targetX =(int)Math.round(mySquad.targetX+w*Math.cos(alpha + turnAng) *radius);
        targetY = (int)Math.round(mySquad.targetY+h*Math.sin(alpha+turnAng)*radius);
        usingSearch=true;
        tempTarget=new Point(rect.getCenterX(),rect.getY());
        findWay();
        askNextPoint();
    }
    public void superPowerActivate(int x, int y){
        Log.d("Subject","super power activated! "+x+" "+y);
        Log.d("Subject"," mySquad targets "+targetX+" "+targetY);
        //tempTarget = new Point(rect.getCenterX(),rect.getY());
        //targetX=mySquad.targetX+position.getX()*w;
        //targetY=mySquad.targetY+position.getY()*h;
        targetX =(int)Math.round(mySquad.targetX+w*Math.cos(alpha + turnAng) *radius);
        targetY = (int)Math.round(mySquad.targetY+h*Math.sin(alpha+turnAng)*radius);
        usingSearch=true;
        tempTarget=new Point(rect.getCenterX(),rect.getY());
        findWay(x,y);
        askNextPoint();
    }
    public void superPowerDeactivate(){
        usingSearch=false;
        standing=0;
    }
    Point movingPoint;
    void canGo(Renderer renderer){
        movingPoint= renderer.move(rect, tx, ty);
        // do u really need it?
    }
   public void goSearch(Renderer renderer){
       if ((int)Math.round(mySquad.targetX+w*Math.cos(alpha + turnAng) *radius)!=targetX) superPowerActivate(); else
       if ((int)Math.round(mySquad.targetY+h*Math.sin(alpha+turnAng)*radius)!=targetY) superPowerActivate();  //<- fix it

       if (shouldGo) {
             Log.d("Subject", "goSearch "+standing+" "+shouldGo);
           if (targetX != rect.getCenterX() || targetY != rect.getCenterY()) {

               tx = ty = 0;
               calcTxTy();
               if (tx==0&&ty==0) {askNextPoint();goSearch(renderer);}

               else {
                   tx *= (vel + speedBonus);
                   ty *= (vel + speedBonus);
                    canGo(renderer);
                   if (movingPoint.getX()==0&&movingPoint.getY()==0) {
                       standing++;
                       if (standing>60) superPowerDeactivate(); else
                           if (standing>50)  superPowerActivate(rect.getX()-10,rect.getY()-10); else
                           if (standing>40)  superPowerActivate(rect.getX()+10,rect.getY()+10); else
                           if (standing>30)  superPowerActivate(rect.getX(),rect.getY()+10); else
                           if (standing>20)  superPowerActivate(rect.getX()+10,rect.getY());


                   }

                 //  myMap.exclude(this);
                   rect.move(tx * movingPoint.getX(), ty * movingPoint.getY());
                 //  myMap.setTaken(this);
                   //}
                   Log.d("Mov", "Comm move " + tx * movingPoint.getX() + " " + ty * movingPoint.getY());
                   Log.d("Mov", "now " + rect.getCenterX() + " " + rect.getCenterY() + " ,but I wanna move to " + tempTarget.getX() + " " + tempTarget.getY() + "and finally to " + targetX + " " + targetY + " shouldGo " + shouldGo);
               }
           } else
           { shouldGo=false; superPowerDeactivate();}

       }
   }
    void askNextPoint() {
        tempTarget = search.getNextPoint();
        if (tempTarget.getX()<0) tempTarget=new Point(targetX,targetY); else
        if (tempTarget.getX()==0) shouldGo=false;
    }
    void calcTxTy(){
        if (rect.getCenterX() < tempTarget.getX()) tx = 1;
        else if (rect.getCenterX() > tempTarget.getX()) tx = -1;
        if (rect.getCenterY() < tempTarget.getY()) ty = 1;
        else if (rect.getCenterY() > tempTarget.getY()) ty = -1;
    }

}