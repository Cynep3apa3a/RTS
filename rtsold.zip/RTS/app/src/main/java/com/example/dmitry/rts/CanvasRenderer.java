package com.example.dmitry.rts;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.util.LruCache;
import android.util.SparseArray;

import com.example.dmitry.rts.Objects.Subjects.Subject;
import com.example.dmitry.rts.Objects.Tiles.Tile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Dmitry on 11.01.2015.
 */
public class CanvasRenderer extends Renderer {
   protected Canvas canvas;
   protected Paint paint;
   protected Context context;
   protected double k=4;
    protected int fit=3;
    Matrix matrix;
    public Rectangle screen;
    Bitmap back;
    MyMap myMap;
    int tile;
    Thread thread;
    LruCache<String,Bitmap> bitmaps;
    LruCache<Integer,Bitmap> tiles;

    ArrayList<Bitmap> test = new ArrayList<>();

    protected Decoder decoder;
    public CanvasRenderer(Context context) {
        this.context = context;
        matrix =new Matrix();
        bitmaps = new LruCache<String,Bitmap>((int)(Runtime.getRuntime().maxMemory())/4);
        tiles = new LruCache<>((int)(Runtime.getRuntime().maxMemory())/4);

        Log.d("Log", "new Canvas");
    }
int counter;
    public void setCanvas(Canvas canvas)
    {
        this.canvas = canvas;

        paint = new Paint();
        paint.setTextSize(16);
        paint.setColor(0xFFFF0000);
        paint.setStrokeWidth(tile/10);
        //Log.d("CanvasRenderer", "counter " + counter);
        counter=0;
        //canvas.drawText("bitmaps: "+bitmaps.size(),0,20,paint);
       // canvas.drawText("tiles: "+tiles.size(),180,20,paint);
        for (Bitmap bitmap : bitmaps.snapshot().values()) {
            canvas.drawText(bitmap.getWidth()+" "+bitmap.getHeight(),10,counter*20+40,paint);
            counter++;
            paint.setTextSize(10);
            if (counter<12) {
                canvas.drawBitmap(Bitmap.createScaledBitmap(bitmap, 50, 50, false), 3 + counter * 50, 30, paint);

                canvas.drawText(bitmap.getWidth() + " " + bitmap.getHeight(), counter * 50 + 3, 50, paint);
            } else
            if (counter<24) {
                canvas.drawBitmap(Bitmap.createScaledBitmap(bitmap, 50, 50, false), 3 + (counter-12) * 50, 83, paint);

                canvas.drawText(bitmap.getWidth() + " " + bitmap.getHeight(), (counter-12) * 50 + 3, 103, paint);
            } else
            if (counter<36)
            {
                canvas.drawBitmap(Bitmap.createScaledBitmap(bitmap, 50, 50, false), 3 + (counter-24) * 50, 136, paint);
                canvas.drawText(bitmap.getWidth() + " " + bitmap.getHeight(), (counter-24) * 50 + 3, 156, paint);
            } else
            {
                canvas.drawBitmap(Bitmap.createScaledBitmap(bitmap, 50, 50, false), 3 + (counter-36) * 50, 190, paint);
                canvas.drawText(bitmap.getWidth() + " " + bitmap.getHeight(), (counter-36) * 50 + 3, 210, paint);
            }

        }
        counter=0;


        paint.setTextSize(9);
//        canvas.drawColor(0xFF000000);
    }
    @Override
    public void drawText(String text, int x, int y) {
        paint.setColor(0xFFFF0000);
        canvas.drawText(text, (int) ((x - screen.getX()) * k), (int) ((y - screen.getY()) * k), paint);
    }

    @Override
    public void drawText(String text, int x, int y, int color) {
        paint.setColor(color);
        canvas.drawText(text, (int) ((x - screen.getX()) * k), (int) ((y - screen.getY()) * k), paint);
    }



Bitmap img;
    @Override
    public void drawImg(String name,Rectangle rect, int ang, int x) {
        if (name.equals(" ")) return;
        if ((img=bitmaps.get(name+x))==null) {img = decoder.getImg(name+x+".png");
            img = Bitmap.createScaledBitmap(img, (int)Math.round(rect.getWidth()*k+0.3),(int) Math.round(rect.getHeight()*k+0.3), false);
            bitmaps.put(name+x, img);
            Log.d("Bitmaps","adding new bitmap (drawImg) "+img+" "+img.getWidth()+" "+img.getHeight());
        }
        if (ang!=0) {
            matrix.postRotate(ang);
            img = Bitmap.createBitmap(img, 0, 0, img.getWidth(), img.getHeight(), matrix, false);
            matrix.postRotate(-ang);
        }
      //  Log.d("CanvasRenderer","drawing sub or build "+name);
        canvas.drawBitmap(img, (int) ((rect.getX() - screen.getX()) *k), (int) ((rect.getY() - screen.getY())*k ), paint);
    }
    @Override
    public void drawBuilding(String name,Rectangle rect) {  //not sure do i really need it
        if ((img=bitmaps.get(name))==null) {
            img = decoder.getImg("Buildings/"+name+".png");
            img = Bitmap.createScaledBitmap(img, (int)Math.round(rect.getWidth()*k+0.3),(int) Math.round(rect.getHeight()*k+0.3), false);

            bitmaps.put(name, img);
            Log.d("Bitmaps","adding new bitmap (drawBuild) "+img+" "+img.getWidth()+" "+img.getHeight());
        }

        canvas.drawBitmap(img, (int) ((rect.getX() - screen.getX()) * k), (int) ((rect.getY() - screen.getY()) * k), paint);
      //  drawText(name,rect.getX()+15,rect.getY()+1);
    }


    @Override
    public void drawTile(String name,Rectangle rect, int param) {
        img = null;
        if (param==0) return;

        if ((img = bitmaps.get(name)) == null) {
                img = decoder.getImg("Tiles/"+name + ".png");
                Bitmap.createScaledBitmap(img,rect.getWidth(),rect.getHeight(),true);
                bitmaps.put(name, img);
                test.add(img);
        }
        //img = Bitmap.createScaledBitmap(img, (int) (rect.getWidth()*param * k), (int) (rect.getHeight()*param * k), false);
      //  Log.d("CanvasRenderer", "drawing tile " + name);
      //if (!name.equals("Tiles/tile.png")) Log.d("CanvasRenderer","drawTle "+name+" "+param+" "+Y+" "+Y1+" "+rect.getX()+" "+rect.getY()+" scaled"+rect.getWidth()*param * k);
        canvas.drawBitmap(img, (int) ((rect.getX() - screen.getX()) * k), (int) ((rect.getY() - screen.getY()) * k), paint);

    }
    @Override
    public void drawTile(int name,Rectangle rect, int param) {
        img = null;
        if (param==0) return;
        img = tiles.get(name);
       try {
           canvas.drawBitmap(img, (int) ((rect.getX() - screen.getX()) * k), (int) ((rect.getY() - screen.getY()) * k), paint);
       } catch (NullPointerException e){
           Log.d("CanvasRenderer","NullPointer "+img+" "+name);
       }
    }





    public  void band2(Tile tile, Tile tile1, Tile tile2, Tile tile3, int d){
        if (tile==null||tile1==null||tile2==null||tile3==null) return;
        if (!(tile.shouldDraw&&tile1.shouldDraw&&tile2.shouldDraw&&tile3.shouldDraw)) return;

        if (bitmaps.get(tile.name+tile1.name+tile2.name+tile3.name)!=null){
            tile.setName(tile.name+tile1.name+tile2.name+tile3.name);
            tile1.shouldDraw=tile2.shouldDraw=tile3.shouldDraw=false;
            return;
        }

        Log.d("CanvasRenderer","CheckingNames new "+tile.name+tile1.name+tile2.name+tile3.name);
        Bitmap bitmap = getBitmap(tile);
        int[] pixels;


        Bitmap newBitmap = Bitmap.createBitmap(bitmap.getWidth()*2,bitmap.getHeight()*2,bitmap.getConfig());
        Log.d("CanvasRenderer"," newBitmap2 "+newBitmap.getWidth()+" "+newBitmap.getHeight());
        pixels = new int[bitmap.getWidth()*bitmap.getHeight()];

        bitmap.getPixels(pixels, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight());
        newBitmap.setPixels(pixels, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight());

        bitmap=getBitmap(tile1);
        if (bitmap.getHeight()!=newBitmap.getHeight()/2||bitmap.getWidth()!=newBitmap.getWidth()/2) return;
        bitmap.getPixels(pixels, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight());
        newBitmap.setPixels(pixels, 0, bitmap.getWidth(), bitmap.getWidth(), 0, bitmap.getWidth(), bitmap.getHeight());

        bitmap=getBitmap(tile2);
        if (bitmap.getHeight()!=newBitmap.getHeight()/2||bitmap.getWidth()!=newBitmap.getWidth()/2) return;

        bitmap.getPixels(pixels, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight());
        newBitmap.setPixels(pixels, 0, bitmap.getWidth(), 0, bitmap.getHeight(), bitmap.getWidth(), bitmap.getHeight());

        bitmap = getBitmap(tile3);
        if (bitmap.getHeight()!=newBitmap.getHeight()/2||bitmap.getWidth()!=newBitmap.getWidth()/2) return;

        bitmap.getPixels(pixels, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight());
        newBitmap.setPixels(pixels, 0, bitmap.getWidth(), bitmap.getHeight(), bitmap.getHeight(), bitmap.getWidth(), bitmap.getHeight());

    /*    int color= 0xFFFF0000;
       if (bitmap.getWidth()>=80) {
           if (newBitmap.getWidth() == 160) color = 0xFF999999;
           if (newBitmap.getWidth() == 160) color = 0xFF00FFFF;
           if (newBitmap.getWidth() == 320) color = 0xFFFFFF00;
           if (newBitmap.getWidth() == 640) color = 0xFF0000FF;
           for (int i = 0; i < newBitmap.getWidth(); i++) {
               newBitmap.setPixel(i, 0, color);
               newBitmap.setPixel(i, newBitmap.getHeight() - 1, color);
           }
           for (int i = 0; i < newBitmap.getHeight(); i++) {
               newBitmap.setPixel(0, i, color);
               newBitmap.setPixel(newBitmap.getHeight() - 1, i, color);
           }
       }*/



        tile.setName(tile.name+tile1.name+tile2.name+tile3.name);
        tile1.shouldDraw=tile2.shouldDraw=tile3.shouldDraw=false;
        bitmaps.put(tile.name,newBitmap);


    }
    public void cleanUp(int d){
        for (String name : bitmaps.snapshot().keySet()) {
            if (bitmaps.get(name).getWidth()<d*tile) {
                Log.d("CleanUp","checking "+name+" "+bitmaps.get(name).getWidth()+" "+bitmaps.get(name).getHeight()+" "+d*tile);
                bitmaps.remove(name);}
        }
    }
    public void setHash(){
        for (String name : bitmaps.snapshot().keySet()) {
           // bitmaps.put(name.hashCode()+"",bitmaps.get(name));
            tiles.put(name.hashCode(),bitmaps.get(name));
            bitmaps.remove(name);
          //  Log.d("SetHash",name+" "+name.hashCode()+bitmaps.get(name.hashCode()+"").getWidth()+" "+bitmaps.get(name.hashCode()+"").getHeight());
        }
    }

    Bitmap getBitmap(Tile tile){
        Bitmap bitmap;
        if ((bitmap=bitmaps.get(tile.name))==null) {
            bitmap = decoder.getImg("Tiles/" + tile.name + ".png");
            bitmap = Bitmap.createScaledBitmap(bitmap, tile.rect.getWidth(), tile.rect.getHeight(), true);
            if (bitmap==null) bitmaps.put(tile.name,(Bitmap)bitmaps.snapshot().values().toArray()[0]);
            Log.d("Bitmaps","adding new bitmap (getBitmap) "+bitmap+" "+bitmap.getWidth()+" "+bitmap.getHeight());
           bitmaps.put(tile.name,bitmap);
            Log.d("CanvasRenderer","got new pic");
        }
       // Log.d("CanvasRenderer","returning "+bitmap+" "+bitmap.getWidth()+" "+bitmap.getHeight());
        return bitmap;
    }



    @Override
    public void drawRect(float x, float y, float  x1, float y1,int color) {
        paint.setColor(color);
        x-=screen.getX();
        x1-=screen.getX();
        y-=screen.getY();
        y1-=screen.getY();
        canvas.drawLine((int) (x * k), (int) (y * k), (int) (x1 * k), (int) (y * k), paint);
        canvas.drawLine((int) (x1 * k), (int) (y * k), (int) (x1 * k), (int) (y1 * k), paint);
        canvas.drawLine((int) (x1 * k), (int) (y1 * k), (int) (x * k), (int) (y1 * k), paint);
        canvas.drawLine((int)(x * k),(int)( y * k),(int)( x * k), (int)(y1 * k), paint);
        canvas.drawLine((int) (x * k), (int) (y * k), (int) (x1 * k), (int) (y1 * k), paint);
        canvas.drawLine((int) (x * k), (int) (y1 * k), (int) (x1 * k), (int) (y * k), paint);
      //  canvas.drawRect(x,y,x1,y1,paint);
       // paint.setColor(0xFF000000);
    }

    @Override
    public void drawChosen(Rectangle rect, int color) {
        paint.setColor(color);
        paint.setStrokeWidth(tile/5);
        int x= rect.getX()-screen.getX();
        int x1= rect.getX1()-screen.getX();
        int y=rect.getY()-screen.getY();
        int y1=rect.getY1()-screen.getY();
        canvas.drawLine((int)(x*k), (int)(y*k), (int)(x1*k), (int)(y*k), paint);
        canvas.drawLine((int)(x1*k), (int)(y*k), (int)(x1*k), (int)(y1*k), paint);
        canvas.drawLine((int)(x1 * k), (int)(y1 * k), (int)(x * k), (int)(y1 * k), paint);
        canvas.drawLine((int)(x * k),(int)( y * k),(int)( x * k), (int)(y1 * k), paint);
        paint.setStrokeWidth(tile/10);
    }


    public double getK(){return k;}
    double q=1;
    @Override

    public void resize(double quality) {
       this.q = quality;
      //if (quality<1)
      //    k=q;
       // else k=1;
        Log.d("Log","renderer resize got "+k+" now "+this.k);
    }

    public void setDecoder(Decoder decoder){
        this.decoder = decoder;
    }
    public Decoder getDecoder(){
        return decoder;
    }
    public int getFit(){return fit;}
    @Override
    public void setScreen(Rectangle rect){
           screen=rect;
        //k=fit = rect.getHeight()/(20 * tile);
        k=fit=1;
        Log.d("Log","renderer setScreen  fit = "+fit+" k="+k+" "+screen.getX()+" "+screen.getY()+" "+screen.getX1()+" "+screen.getY1());
    }

    @Override
    public void moveScreen(int a, int b){
        screen.move(a,b);
        Log.d("Log","renderer setScreen  fit = "+fit+" k="+k);

    }

    final static Point NO = new Point(0,0);
    final static Point OX = new Point(1,0);
    final static Point OY = new Point(0,1);
    final static Point YES = new Point(1,1);
    int x,x1;
    int y,y1;
    @Override
    public Point move(Rectangle rect,int tx, int ty) {
        boolean ox=true;
        boolean oy=true;
        if (tx>0)
        {
            if (myMap.isEngagedCord(rect.getX1()+tx,rect.getY())||myMap.isTaken(rect.getX1()+tx,rect.getY())>1||
                    myMap.isEngagedCord(rect.getX1()+tx,rect.getCenterY())||myMap.isTaken(rect.getX1()+tx,rect.getCenterY())>1) ox=false;
        } else
        if (tx<0)
        {
            if (myMap.isEngagedCord(rect.getX()+tx,rect.getY())||myMap.isTaken(rect.getX()+tx,rect.getY())>1||
                    myMap.isEngagedCord(rect.getX()+tx,rect.getCenterY())||myMap.isTaken(rect.getX()+tx,rect.getCenterY())>1) ox=false;
        } else ox=false;
        if (ty>0)
        {
            if (myMap.isEngagedCord(rect.getX(),rect.getY1()+ty)||myMap.isTaken(rect.getX(),rect.getY1()+ty)>1||
                    myMap.isEngagedCord(rect.getCenterX(),rect.getY1()+ty)||myMap.isTaken(rect.getCenterX(),rect.getY1()+ty)>1) oy=false;
        } else
        if (ty<0)
        {
            if (myMap.isEngagedCord(rect.getX(),rect.getY()+ty)||myMap.isTaken(rect.getX(),rect.getY()+ty)>1||
                    myMap.isEngagedCord(rect.getCenterX(),rect.getY()+ty)||myMap.isTaken(rect.getCenterX(),rect.getY()+ty)>1) oy=false;
        } else oy=false;
        Log.d("CanvasRenderer move ",ox+" "+oy+"  "+tx+" "+ty);
        if (ox) return oy? YES:OX; else
            return oy? OY:NO;

    }

    @Override
    public void setMyMap(MyMap myMap) {
        this.myMap = myMap;
        tile = myMap.getTILE_SIZE();
    }

    @Override
    public void drawHpOval(Rectangle rect, int HP, int hp) {
        if (HP<-1) {paint.setColor(0xFF33CCCC);} else
        if (hp==HP) {paint.setColor(0xFF00CC00);} else
            if (hp>HP*0.75) paint.setColor(0xFF88AA00); else
                if (hp>HP*0.3) paint.setColor(0xFFCCAA00); else
                    paint.setColor(0xFFAA0000);
      //  canvas.drawCircle((int)((rect.getCenterX()-screen.getX())*k),(int)((rect.getCenterY()-screen.getY())*k),(int)(rect.getWidth()/2*k),paint);
        canvas.drawLine((int)((rect.getX()-screen.getX())*k),(int)((rect.getY1()-screen.getY())*k),(int)((rect.getX()+hp-screen.getX())*k),(int)((rect.getY1()-screen.getY())*k),paint);
    }

    @Override
    public void drawLine(Point a, Point b) {
        paint.setColor(0xFFAAAA00);
        canvas.drawLine(a.getX(),a.getY(),b.getX(),b.getY(),paint);
    }

    @Override
    public void drawButton(String name,Rectangle rect, int state) {
        if (name.equals(" ")) return;
        //if ((img=bitmaps.get(name))==null) {img = decoder.getImg(name+".png");img = Bitmap.createScaledBitmap(img, rect.getWidth()*k, rect.getHeight()*k, false); bitmaps.put(name, img); Log.d("CanvasRenderer", "size = " + bitmaps.size());}

        canvas.drawBitmap(img, (int) ((rect.getX()) *k*q), (int) ((rect.getY())*k*q ), paint);
    }


}

