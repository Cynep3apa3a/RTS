package com.example.dmitry.rts;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

class MyAdapter extends ArrayAdapter<String> {
   List<String> objects;
   Decoder decoder;
   int type;
   LayoutInflater inflater;
   public MyAdapter(Context context, int resource, int textViewResourceId, List<String> objects, int type, LayoutInflater inflater) {
       super(context, resource, objects);
       this.objects = objects;
       decoder = new Decoder();
       decoder.setContext(context);
       this.type=type;
       this.inflater = inflater;

   }
    public void add(String name){
       // objects.add(name);
///        notifyDataSetChanged();
    }

   @Override
   public View getView(int position, View convertView, ViewGroup parent){
       View view = convertView;
       if(view==null){
           if (type==1) {
               view = inflater.inflate(R.layout.my_list_layout, parent, false);

               TextView label = (TextView) view.findViewById(R.id.myListText);
               label.setText(objects.get(position));

               ((ImageView) view.findViewById(R.id.icon)).setImageBitmap(decoder.getMapThumb(objects.get(position), view.getWidth(), view.getHeight()));
           } else
           {
               view = inflater.inflate(R.layout.my_squad_layout, parent, false);
               TextView label = (TextView) view.findViewById(R.id.mySquadText);
               label.setText(objects.get(position));
               ((ImageView) view.findViewById(R.id.squad_icon)).setImageBitmap(decoder.getMapThumb(objects.get(position), view.getWidth(), view.getHeight()));


           }
       }
       return view;
   }
}
