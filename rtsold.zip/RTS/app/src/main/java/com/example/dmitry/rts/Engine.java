package com.example.dmitry.rts;

import android.graphics.Canvas;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;
import android.view.SurfaceHolder;
import android.widget.Button;

import com.example.dmitry.rts.Objects.Subjects.Squad;

import java.util.ArrayList;

/**
 * Created by Dmitry on 15.01.2016.
 */
public class Engine extends AsyncTask implements Runnable {
    MyView myView;

    MyMap myMap;
    boolean active = true;
    Decoder decoder;
    final int FPS = 20;
   final int tickTime = 1000/FPS;
    Renderer renderer;
    DataBase db;

    int skippedFrames=0;
    public Engine(MyView myView) {
        Log.d("Log","new Engine");
        thread = new Thread(this,"Engine");
        decoder = new Decoder();
        decoder.setContext(myView.getContext());
        myMap = new MyMap();
        myMap.setDecoder(decoder);
        myMap.setEngine(this);

        db = new DataBase(myView.getContext(),"buildings");

        Log.d("MyMap", " Engine MyMap " + myMap + "");

        renderer = new CanvasRenderer(myView.getContext());
        renderer.setDecoder(decoder);
        renderer.setMyMap(myMap);

       // renderer.start();
        //bitmap = decoder.getImg("Tiles/grass.png");
        this.myView = myView;
        myView.setMap(myMap);
        thread.start();
    }
    public void addBuilding(int x, int y){Log.d("Log","Engine adding building"); db.addBuilding("wall", x, y);}
    public StringBuilder getBuilding(){return db.getBuilding();}
    public int changeFPS(){
        return tickTime;
    }

    public void fin() {
        running = false;
    }

    private volatile boolean running;


    public boolean isRunning(){return running;}

    public void pause(){ if (active) active =false; else active =true; }
    long beginTime;
    long workingTime;
    long sleepTime;
    int time=0;
    Canvas canvas;
    Thread thread;
    @Override
    public void run() {
        Log.d("Log","engine running...");




        SurfaceHolder holder = myView.getHolder();
        canvas = holder.lockCanvas();
        if (canvas!=null) {
            renderer.setCanvas(canvas);

            myMap.fill(renderer);

            myView.chosen = myMap.getSquad(0);
            //myMap.update(renderer, time);
           // myMap.draw(renderer,myView.k);
            holder.unlockCanvasAndPost(canvas);
        }

        running = true;
        while (running) {
             beginTime = System.currentTimeMillis();
           // holder.setFixedSize((int)(1280/renderer.getK()), (int)(720/renderer.getK()));
             canvas = holder.lockCanvas();
                if (canvas != null) {
                    canvas.drawColor(0xFF000000);

                    renderer.setCanvas(canvas);

                        if (time>100) time=0;
                    if (active) {     myMap.update(renderer,time);
                        time++;
                        //renderer.drawImg("Tles/grass",((CanvasRenderer)renderer).screen,0,1);
                    }
                    //draw
                myMap.draw(renderer,myView.k);
                   // renderer.drawText("build: " + myView.build + "", 900, 200);
                   // renderer.drawText("ang: "+myMap.squads.get(0).a+"",900, 300);
                    holder.unlockCanvasAndPost(canvas);
                }
             workingTime = (System.currentTimeMillis() - beginTime);
             sleepTime = tickTime - workingTime;
            if (sleepTime >=0)
                try {
                   // Log.d("Log"," done "+" sleep: "+ sleepTime +" working: "+ workingTime);
                   // sleep(sleepTime);
                    Thread.sleep(sleepTime);
                } catch (InterruptedException e) {
                    e.printStackTrace();

            } else
                while (sleepTime <0){
                    skippedFrames++;
                   // Log.d("Log"," frame skipped : "+skippedFrames+" sleep: "+ sleepTime +" working: "+ workingTime);
                    sleepTime +=tickTime;
                }
        }
        //myMap.apocalypse();
        System.gc();
    }

    @Override
    protected Void doInBackground(Object[] params) {

        return null;
    }
    public void addSquadButton(Squad s, int a){
        Log.d("SquadButton","sending to handler "+a+" "+s);
        handler.sendMessage(handler.obtainMessage(a,s));
    }

     Handler handler = new Handler() {
        public void handleMessage(android.os.Message msg) {
            Log.d("SquadButton","message recivied"+msg.what+" "+msg.obj);

        }
    };
}
