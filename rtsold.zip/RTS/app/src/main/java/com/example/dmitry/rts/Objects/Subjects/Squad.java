package com.example.dmitry.rts.Objects.Subjects;

import android.util.Log;

import com.example.dmitry.rts.MyMap;
import com.example.dmitry.rts.Objects.Buildings.Building;
import com.example.dmitry.rts.Objects.Subjects.Heroes.Hero;
import com.example.dmitry.rts.Objects.Subjects.Heroes.HeroCommander;
import com.example.dmitry.rts.Objects.Subjects.Warriors.Warrior;
import com.example.dmitry.rts.Objects.Subjects.Warriors.WarriorCommander;
import com.example.dmitry.rts.Point;
import com.example.dmitry.rts.Rectangle;
import com.example.dmitry.rts.Renderer;

import java.util.ArrayList;
import java.util.Arrays;


/**
 * Created by Dmitry on 16.01.2016. fully rewritten on 24.01.2016
 */
public class Squad {
    volatile ArrayList<Subject> squad;
    int x;
    int y;
    int commander;
    String formationType;
    transient Formation formation;
    transient Point commanderPos;
    transient Point commanderCoordinates;
    transient MyMap myMap;
    int id;
    int length;
    int team;

    public int left,right,top,bottom,midX,midY;



    int w,h,atcDist;

    public Squad(int x, int y, String type, int quantity,MyMap myMap, int team){
        formation = new Formation(this);
        this.myMap = myMap;
        commander =0;
        length = quantity;

        switch (type){ // filling the squad;
            case("warrior"): squad = new ArrayList<>(); squad.add(commander,new WarriorCommander(commander,myMap)); //new Commander
                for (int i=0; i<length; i++) if (i!=commander)squad.add(i,new Warrior(i,myMap));break;//default square formation

            case("hero"): squad = new ArrayList<>(); squad.add(commander,new HeroCommander(commander,myMap)); //new Commander
                for (int i=0; i<length; i++) if (i!=commander)squad.add(i,new Hero(i,myMap));break;//default square formation
        }
        this.x=targetX=x;
        this.y=targetY=y;
        w=squad.get(0).w;
        h=squad.get(0).h;
        setSquareFormationType();
        setTeam(team);
        for (int i=0; i<squad.size(); i++) squad.get(i).setRect(x, y); //setting default position;
        //for (int i=0; i<squad.length; i++) squad[i].setPos(formation.square(squad.length, i)); // setting absolute position in the squad
        // setting relative position in the squad (commander 0,0
        for (int i=0; i<squad.size(); i++) squad.get(i).setSquad(this); // setting squad obj;




        atcDist = squad.get(0).atcDist;

    }
    public void addWayPoint(int x, int y){squad.get(commander).search.addWayPoint(x,y);}

    public void wayPaved(){
        squad.get(commander).shouldGo=true;
        squad.get(commander).search.resetCounter();
        squad.get(commander).askNextPoint();

    }
    public Subject getCommander(){return squad.get(commander);}
    public Subject getOne(int a){ try{return squad.get(a);} catch (ArrayIndexOutOfBoundsException e){} return  null;}
    public void setTeam(int team){ this.team=team; for (int i=0; i<length; i++) squad.get(i).setTeam(team); }
    public int getTeam(){ return team;}
    public void setId(int id){this.id=id;}
    public int getId(){return id;}
    boolean chosen = false;
    public void setChosen(boolean chosen){ this.chosen = chosen;}
    void setRelativePosition(){
        commanderPos = squad.get(commander).getAbsolutePos();
        for (int i=0; i<length; i++) {squad.get(i).setPos(squad.get(i).getAbsolutePos().minus(commanderPos));
            //Log.d("Log", "relative pos for " + i + " is " + squad[i].getPos().minus(commanderPos).getX() + " " + squad[i].getPos().minus(commanderPos).getY());
            }
        commanderCoordinates = new Point(x+commanderPos.getX()*w,y+commanderPos.getY()*h);
        updateCorners();
    }
    void updateCorners(){
        left=formation.getLeft()*w+commanderCoordinates.getX();
        right=formation.getRight()*w+commanderCoordinates.getX();
        top=formation.getTop()*h+commanderCoordinates.getY();
        bottom=formation.getBottom()*h+commanderCoordinates.getY();
        midX=(left+right)/2/w+((left+right)/w)%2;
        midY=(top+bottom)/2/h+((top+bottom)/h)%2;
    }


    public void update(Renderer renderer, int time){
         commanderCoordinates = squad.get(commander).getCoordinates();
        updateCorners();

        if (time==id||time==100-id) {
            enemyTemp = myMap.getClosest(left - 20, top - 20, right + 20, bottom + 20, team);
            if (enemyTemp != null) alert();
        }

        for (int i = 0; i < length; i++)
            squad.get(i).update(renderer, time);
    }
Squad enemyTemp;

    public void alert(){
        Log.d("Squad", "alert " + id + " " + ((midY - enemyTemp.midY) * (midY - enemyTemp.midY) + (midX - enemyTemp.midX) * (midX - enemyTemp.midX)));
        turnEach(((int)Math.toDegrees(Math.atan2(midY-enemyTemp.midY,midX-enemyTemp.midX)))+180);
        if ((midY-enemyTemp.midY)*(midY-enemyTemp.midY)+(midX-enemyTemp.midX)*(midX-enemyTemp.midX)<16) enemyNearby(); else
            for (int i = 0; i < length; i++) if (squad.get(i).hp!=0)
                squad.get(i).enemyNearby=false;
    }
    public void attack(){
    }
    public void enemyNearby(){

        for (int i = 0; i < length; i++) if (squad.get(i).hp!=0)
            squad.get(i).enemyNearby=true;
        Log.d("Squad",id+" enemyNearby "+enemyTemp);
    }


    public int getCommanderSpeedBonus(){return squad.get(commander).speedBonus;}

 public void draw(Renderer renderer){
        for (int i = 0; i < length; i++)
            try {if (chosen) renderer.drawChosen(squad.get(i).getRect(), 0xFFDDCC00);
                squad.get(i).draw(renderer);

            } catch (NullPointerException e) {
            }
   //  renderer.drawText(left+" "+top+" "+right+" "+bottom,x-20,y);

    }
    int targetX,targetY;
    public Building targetBuilding;
    public Squad targetSquad;


    public int getX(){return x;}
    public int getY(){return y;}

    public void setTarget(int x, int y){

            targetX=x; targetY=y;
        Log.d("Squad","setTarget "+commander+" "+targetX+" "+targetY);
        (squad.get(commander)).setTarget(targetX,targetY);

        try{targetBuilding = myMap.getBuilding(x,y);} catch (NullPointerException e){ targetBuilding=null;}
        try{targetSquad = myMap.isEnemy(x,y,team).getSquad();} catch (NullPointerException e){ targetSquad=null;}
    }

    public void rotate(int alpha){
        for (int i=0; i<length; i++) try{squad.get(i).turn(alpha);} catch (Exception e){}
    }
    public void turnEach(int alpha){
        for (int i=0; i<length; i++) try{squad.get(i).turnEach(alpha);} catch (Exception e){}
    }

    public void setSquareFormationType() {
        formationType = "square";
           for (int i = 0; i < length; i++) squad.get(i).setAbsolutePos(formation.square(length, i));
        setRelativePosition();
    }

    public void setRectFormationType(int side) {
        formationType = "rect";
        for (int i = 0; i < length; i++) squad.get(i).setAbsolutePos(formation.rectangle(side, i));
        setRelativePosition();
    }
    public void setPincerFormationType(int side) {
        formationType = "pincer";
        for (int i = 0; i < length; i++) squad.get(i).setAbsolutePos(formation.pincer(side, i));
        setRelativePosition();
    }


    void newCommander(String type){ //here must be smart algorithm, but who cares
        if (squad.size()==1) return;

        int n;
        for (n=0; n<squad.size();n++)
            if (!(squad.get(n) instanceof Commander)) break;
        Log.d("Squad","new Commander "+type+" n "+n);
        switch (type) {
            case "warriorcommander": squad.add(n, new WarriorCommander(squad.get(n).id, myMap, squad.get(n).hp, squad.get(n).rect, squad.get(n).position, squad.get(n).absolutePos, this));
                break;
        }
        squad.remove(n+1);
        commander=n;
    }
    public void destroyMe(Subject subject){
        Log.d("Squad", "destroying" + subject);
        if (subject instanceof Commander) newCommander(subject.getClass().getSimpleName().toLowerCase());
        myMap.exclude(subject);
        squad.remove(subject);
        length--;

    }


}
