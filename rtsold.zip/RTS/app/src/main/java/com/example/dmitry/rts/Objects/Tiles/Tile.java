package com.example.dmitry.rts.Objects.Tiles;

import android.graphics.Bitmap;
import android.util.Log;

import com.example.dmitry.rts.Decoder;
import com.example.dmitry.rts.MyMap;
import com.example.dmitry.rts.Objects.Buildings.Building;
import com.example.dmitry.rts.Objects.Subjects.Subject;
import com.example.dmitry.rts.Rectangle;
import com.example.dmitry.rts.Renderer;

import java.io.Serializable;
import java.util.AbstractList;
import java.util.ArrayList;

/**
 * Created by Dmitry on 11.12.2015.
 */
public class Tile implements Serializable{
    Building building;
    int velBonus;
    boolean updateQuantity = true;
    public Rectangle rect;
    public String name;
    public int hash;
    public int param=1;
    public int defenceBonus;
    public int speedBonus;
    int zoneSide;
    int x,y;
    int w;
    Subject subjects[] = new Subject[10];
    int quantity=0;
    transient MyMap myMap;
    public  Tile(int x, int y,MyMap myMap){
        this.myMap=myMap;
        this.x=x;
        this.y=y;
        w = myMap.getTILE_SIZE();
        zoneSide=myMap.zoneSide;
        rect = new Rectangle(x*myMap.getTILE_SIZE(),y*myMap.getTILE_SIZE(),
                x*myMap.getTILE_SIZE()+myMap.getTILE_SIZE(),y*myMap.getTILE_SIZE()+myMap.getTILE_SIZE());
        setName();
    }
     public void setName(){name = getClass().getSimpleName().toLowerCase();}
    public void setName(String s){name = s.toLowerCase();}
    public void setName(int hash){
        this.hash = hash;}

    public void setSubject(Subject subject){subjects[subject.getTeam()] = subject; updateQuantity=true;
        myMap.zoneSquads[x/zoneSide][y/zoneSide].remove(subject.getSquad());
        myMap.zoneSquads[x/zoneSide][y/zoneSide].add(subject.getSquad());
    }
    public void setBuilding(Building building){this.building=building; }
    public void exclude(Subject subject){subjects[subject.getTeam()]=null; updateQuantity=true;
        myMap.zoneSquads[x/zoneSide][y/zoneSide].remove(subject.getSquad());

    }
    public void exclude(Building building){this.building=null;}
    public boolean isEngaged(){return  (this instanceof Water)|| building!=null;}
    public Subject getAlly(int team){return subjects[team];}
    public Subject isEnemy(int team){
        if (subjects[0]!=null&&0!=team) return subjects[0]; else
        if (subjects[1]!=null&&1!=team) return subjects[1]; else
        if (subjects[2]!=null&&2!=team) return subjects[2]; else
        if (subjects[3]!=null&&3!=team) return subjects[3]; else
        if (subjects[4]!=null&&4!=team) return subjects[4]; else
        if (subjects[5]!=null&&5!=team) return subjects[5]; else
        if (subjects[6]!=null&&6!=team) return subjects[6]; else
        if (subjects[7]!=null&&7!=team) return subjects[7]; else
        if (subjects[8]!=null&&8!=team) return subjects[8]; else
        if (subjects[9]!=null&&9!=team) return subjects[9]; else
            return null;
    }
    public Building getBuilding(){return building;}
    public int quanSubjects(){if (updateQuantity) updateQuantity();  return quantity;}
    void updateQuantity(){quantity=0; for (int i=0; i<subjects.length; i++) if (subjects[i]!=null) quantity++;}
    public boolean canControl(int team) {return subjects[team]!=null;}
    public boolean shouldDraw = true;

    public void draw(Renderer renderer, double k) throws NullPointerException{
        if (shouldDraw) {
           renderer.drawTile(hash,rect,param);
        }
       // renderer.drawRect(rect.getX(),rect.getY(),rect.getX1(),rect.getY1(),0x77FFFF22);
    }
    public int getSpeedBonus(){
        return speedBonus;
    }
    public int getDefenceBonus(){
        return defenceBonus;
    }
}
