package com.example.dmitry.rts;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.SeekBar;
import com.example.dmitry.rts.Objects.Buildings.Wall;
import com.example.dmitry.rts.Objects.Subjects.Squad;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

/**
 * Created by Dmitry on 11.01.2016.
 */
public class MyView extends SurfaceView implements
        View.OnTouchListener, SurfaceHolder.Callback, View.OnClickListener, AdapterView.OnItemClickListener,AdapterView.OnItemSelectedListener, SeekBar.OnSeekBarChangeListener{
    MyMap myMap;
    Engine engine;

    int w,h;

    double k =1;
    boolean build=false;
    Rectangle screen;
    SeekBar seekBar;
    int map;
    Squad chosen; //-squad youve chosen
    boolean paveTheWay=false; // if true you can "draw" the path


    public MyView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        Log.d("Log", "myView context attrs defStyleArr");


        //renderer = new CanvasRenderer(context);
        getHolder().addCallback(this);


        this.setOnTouchListener(this);
       // scale = (ImageButton) findViewById(R.id.scaleButton);
       // scale.setOnClickListener(this);
    }

    public MyView(Context context) {
        super(context);
        Log.d("Log", " context");
        getHolder().addCallback(this);

        this.setOnTouchListener(this);


    }


    public MyView(Context context, AttributeSet attrs) {
        super(context, attrs);
        Log.d("Log", " context attrs");
        MapEditor.myView=this;
        MapChoose.myView=this;
//        MapChoose.mapChoose.setParams(attrs);

        getHolder().addCallback(this);
        this.setOnTouchListener(this);
        //scale = (ImageButton) findViewById(R.id.scaleButton);
       // scale.setOnClickListener(this);

    }

    MyAdapter adapter;
    public void setAdapter(MyAdapter adapter){
        this.adapter = adapter;
        Log.d("MyView","adapter set "+adapter);

    }
    public void add(Squad s){
        adapter.add(s.getCommander().getName());
    }

    public void setMap(MyMap myMap) {
        this.myMap = myMap;


    }

    int oldX=0;
    int oldY=0;
    double oldDist;
    double newDist;
    int deltaX;
    int deltaY;
    int touchedX;
    int touchedY;
    boolean moved = false;
    boolean wayPaved = false;
    int lastTileX;
    int lastTileY;
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        int upPI = 0;
        int downPI = 0;
        int actionMask = event.getActionMasked();
        // индекс касания
        int pointerIndex = event.getActionIndex();
        // число касаний
        int pointerCount = event.getPointerCount();
        String s = "";
        switch (actionMask) {
            case MotionEvent.ACTION_DOWN: // первое касание
                touchedX =(int)( event.getX(0)*w/(double)getWidth());
                touchedY = (int) (event.getY(0)*h/(double)getHeight());

                Log.d("MyView","DOWN "+touchedX+" "+touchedY);break;
            case MotionEvent.ACTION_POINTER_DOWN: // последующие касания
                break;

            case MotionEvent.ACTION_UP: // прерывание последнего касания
            case MotionEvent.ACTION_POINTER_UP: // прерывания касаний
                if (!moved) {
                    if (wayPaved){
                         {chosen.wayPaved();
                            Log.d("MyView","wayPaved");
                         wayPaved=false;}
                    }
                    touched();
                }
                moved=false;
                break;

            case MotionEvent.ACTION_MOVE: // движение

               if (pointerCount==1){
                   if (paveTheWay&&chosen!=null&&!engine.active){
                       wayPaved=true;
                       Log.d("MyView","PaveTheWay"+lastTileX+" "+lastTileY);

                       if (lastTileX!=(int)(event.getX(0)/k/2/myMap.getTILE_SIZE())||
                               lastTileY!=(int)(event.getY(0)/k/2/myMap.getTILE_SIZE())) {
                           lastTileX = (int) (event.getX(0) / k /2/ myMap.getTILE_SIZE());
                           lastTileY=(int)(event.getY(0)/k/2/myMap.getTILE_SIZE());
                           chosen.addWayPoint(lastTileX,lastTileY);
                       }


                   } else {
                       moved = true;
                       if (touchedX != -1 && touchedY != -1) {
                           deltaX = touchedX - (int) (event.getX(0) * w / (double) getWidth());
                           deltaY = touchedY - (int) (event.getY(0) * h / getHeight());
                           touchedX = -1;
                           touchedY = -1;
                       } else {
                           deltaX = oldX - (int) (event.getX(0) * w / (double) getWidth());
                           deltaY = oldY - (int) (event.getY(0) * h / (double) getHeight());
                       }

                       oldX = (int) (event.getX(0) * w / (double) getWidth());
                       oldY = (int) (event.getY(0) * h / (double) getHeight());
                       if (Math.abs(deltaX) < 1 && Math.abs(deltaY) < 1 ) moved = false;
                       //if (Math.abs(deltaX)>1||Math.abs(deltaY)>1)
                   }
               } //else
                  /* if (pointerCount==2){

                       if ((newDist=Math.sqrt( (event.getX(0)-event.getX(1))*(event.getX(0)-event.getX(1)) + event.getY(0)-event.getY(1)*(event.getY(0)-event.getY(1)) ))-oldDist>1){
                           scale(newDist/oldDist);
                           Log.d("Multi",newDist+" "+oldDist+" k="+engine.renderer.getK());
                       }
                   }*/

                for (int i = 0; i < pointerCount; i++){
                    {}
                }
                break;
        }
        if (moved) { moveScreen(deltaX/2,deltaY/2);}

        return true;
    }
    void touched() {
        Log.d("MyView", touchedX + " " + touchedY + " chosen:" + chosen + " build " + build + " k " + k);
        if (build) {

            myMap.addBuilding(new Wall(((int) ((touchedX / k) + screen.getX()))/(2*myMap.getTILE_SIZE())*(2*myMap.getTILE_SIZE()), ((int) (touchedY / k + screen.getY()))/(2*myMap.getTILE_SIZE())*(2*myMap.getTILE_SIZE()), 0));
          //  myMap.decoder.add(myMap.getLastB());
          /*  myMap.addTile((int) ((touchedX / k) + screen.getX())/myMap.getTILE_SIZE(),
                    (int) (touchedY / k + screen.getY())/myMap.getTILE_SIZE(),"tile");
            myMap.decoder.add(myMap.getTile((int) ((touchedX / k) + screen.getX())/myMap.getTILE_SIZE(),
                    (int) (touchedY / k + screen.getY())/myMap.getTILE_SIZE()));*/
        }
        else if (myMap.isTaken((int) (touchedX / k + screen.getX()), (int) (touchedY / k + screen.getY())) > 0)  //<- fix it
        {
            if (myMap.canControl((int) (touchedX / k + screen.getX()), (int) (touchedY / k + screen.getY()),0)) {
                chosen.setChosen(false);
                chosen = myMap.getSquad((int) (touchedX / k  + screen.getX()), (int) (touchedY / k  + screen.getY()),0);
                chosen.setChosen(true);
            } else
                if (chosen!=null){
                    chosen.setTarget(Math.max(0, (int) (touchedX / k+ screen.getX())),
                            Math.max(0, (int) (touchedY / k) + screen.getY()));
                }
        }
        else {
            Log.d("MyView","SetTarget"+Math.max(0, (int) (touchedX / k + screen.getX()))+" "+ Math.max(0, (int) (touchedY / k) + screen.getY()));
            chosen.setTarget(Math.max(0, (int) (touchedX / k+ screen.getX())),
                    Math.max(0, (int) (touchedY / k) + screen.getY()));
        }
    }
   public void scale(int k){
       this.k=(k/(10.0));

       engine.renderer.resize(this.k);
Log.d("MyView", "scale "+this.k);
      // if (this.k>=1)
       getHolder().setFixedSize((int) (w / this.k ), (int) (h / this.k ));

        //   getHolder().setFixedSize(w*2/k,h*2/k);

    }
    public void moveScreen(int x, int y){
        screen.move(x, y);
        Log.d("Log", "MyView moveScreen screen " + this.screen.getX() + " " + this.screen.getY() + " " + this.screen.getX1() + " " + this.screen.getY1());
        engine.renderer.moveScreen(x, y);
    }
    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        buildTheScene();



    }
    public void pause(){ engine.pause();}
    public int changeFPS(){return engine.changeFPS();}

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        Log.d("MyView", "surface destroyed");
        engine.fin();
    }
    @Override
    public void onClick(View v) {

        Log.d("Log", " 'click!' - look, it works!");
        switch (v.getId()) {
            case (R.id.pause): engine.pause(); break;
            case (R.id.build_aim):if (paveTheWay) paveTheWay=false; else paveTheWay=true; break;
            case (R.id.rotate): chosen.rotate(45);  break;
            case (R.id.formation): int r =new Random().nextInt(10); chosen.setRectFormationType(r+4); break;
            case R.id.super_power:  break;
            case R.id.save :save();

        }
    }

    void restart() {
        Log.d("Log", "-------------restarting...-------------");
        killEngine();

        Log.d("Log", "----------------done----------------");

    }
    void killEngine(){
        if (engine != null) {
        engine.fin();
        }
    }
    void buildTheScene(){
    this.engine =new Engine(this);
        if (MapEditor.W!=0&&MapEditor.H!=0) {
            build=true;
        }
        //w = Math.min(this.getWidth(),1280);
        //h = Math.min(this.getHeight(),720);
        this.w=1920;
        this.h=1080;

        screen = new Rectangle(0, 0, w, h);
        engine.renderer.setScreen(screen);

        scale(10);
        scale(50);
        Log.d("Log", " surfaceCreated. screen " + this.screen.getX() + " " + this.screen.getY() + " " + this.screen.getX1() + " " + this.screen.getY1());

    }
    public void save(){
        Log.d("MyView", "saving...");
        try {
            engine.decoder.save(myMap, "map_" + (new SimpleDateFormat("yyyyMMdd_HHmmss")).format(new Date()));
          //  engine.decoder.save(myMap);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (position){
            case 0: Log.d("Log", "spinnnner! reset ");getContext().deleteDatabase("buildings"); restart(); break;
            case 1:Log.d("Log", "spinner restarting..."); restart();break;
            case 2: break;
           // case 2: killEngine();Log.d("Log", "spinnnner! 2"); view.bringToFront(); parent.bringToFront();
        }
    }


    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        scale(progress+2);
        Log.d("MyView","Scaling "+progress+1);

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
    public void createNewButton(Squad squad){

    }


    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

    }
}