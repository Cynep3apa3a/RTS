package com.example.dmitry.rts;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.CursorIndexOutOfBoundsException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.dmitry.rts.Objects.Buildings.Building;

import java.util.Objects;

/**
 * Created by Dmitry on 20.01.2016.
 */
public class DataBase extends SQLiteOpenHelper {
    public DataBase(Context context, String name) {
        super(context, name, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("Log", "new db");
        String CREATE_TABLE = "CREATE TABLE buildings ( " +
                "type TEXT, " +
                "x INTEGER, "+
                "y INTEGER )";
try {
    db.execSQL(CREATE_TABLE);
} catch (SQLiteException e){}
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public void addBuilding(String building,int x,int y){
        Log.d("DB","adding building "+ building+" ");
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("type", building.toLowerCase());
        values.put("x", x);
        values.put("y", y);

        db.insert("buildings", // table
                null, //nullColumnHack
                values); // key/value -> keys = column names/ values = column values

        db.close();
    }
    public StringBuilder getBuilding(){
        // 1. get reference to readable DB
        SQLiteDatabase db = this.getReadableDatabase();
        StringBuilder s = new StringBuilder();

        // 2. build query
        Cursor cursor = db.query("buildings", null, null, null, null, null, null);
        // 3. if we got results get the first one
        if (cursor != null) {
            cursor.moveToFirst();}
        while (cursor!=null)
           try{ s.append(cursor.getString(0));
            s.append(" ");
            s.append(cursor.getString(1));
            s.append(" ");
            s.append(cursor.getString(2));
               s.append("\n");
           cursor.moveToNext();
           } catch (CursorIndexOutOfBoundsException e){ return s;}

        //log
        Log.d("DB","gotBuilding "+ s.toString());

        // 5. return book
        return s;
    }

}
