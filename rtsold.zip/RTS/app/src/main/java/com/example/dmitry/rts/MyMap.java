package com.example.dmitry.rts;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.example.dmitry.rts.Objects.Buildings.Building;
import com.example.dmitry.rts.Objects.Buildings.SimpleTower;
import com.example.dmitry.rts.Objects.Buildings.Wall;
import com.example.dmitry.rts.Objects.Buildings.Portal;
import com.example.dmitry.rts.Objects.Subjects.Squad;
import com.example.dmitry.rts.Objects.Subjects.Subject;
import com.example.dmitry.rts.Objects.Tiles.Road;
import com.example.dmitry.rts.Objects.Tiles.Tile;
import com.example.dmitry.rts.Objects.Tiles.Water;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by Dmitry on 11.01.2016.
 */
public class MyMap  {
    public  boolean[][] inSearch;
    protected int W;
    protected int H;
    protected Engine engine;

    public int zoneSide=15; //in tiles
    public int getTILE_SIZE() {
        return TILE_SIZE;
    }
    public int getW(){return W;}
    public int getH(){return H;}
    final protected int TILE_SIZE = 10;
    public void setEngine(Engine e){
        engine=e;
    }
    public boolean shouldUpdate = true;

public Building getBuilding(int id){try{return buildings.get(id);} catch (IndexOutOfBoundsException e){} return null;}

    protected Rectangle screen;
public boolean isEngagedCord(int x, int y){ try{return map[x/TILE_SIZE][y/TILE_SIZE].isEngaged();} catch (ArrayIndexOutOfBoundsException e){} return true;}
public boolean isEngaged(int x, int y){ try{return map[x][y].isEngaged();} catch (ArrayIndexOutOfBoundsException e){} return true;}

    public void setEngaged(Building building) throws Exception{
        for (int i=0; i<building.engaged.length; i++) {
            if (building.engaged[i])
            map[building.getRect().getX()/TILE_SIZE+(i/(side/TILE_SIZE))][building.getRect().getY()/TILE_SIZE+(i%(side/TILE_SIZE))].setBuilding(building);
        }
}
    public Tile getTile(int x, int y){try{return map[x][y];} catch (ArrayIndexOutOfBoundsException e){} return null;}

    int takenX, takenY, takenX1, takenY1; //oldCoord

    public void setTaken(Subject subject){ //for simple coordinates
        takenX = (subject.getRect().getX()+1)/TILE_SIZE;
        takenX1 = (subject.getRect().getX1()-1)/TILE_SIZE;
        takenY = (subject.getRect().getY()+1)/TILE_SIZE;
        takenY1 = (subject.getRect().getY1()-1)/TILE_SIZE;

        for (int i=takenX; i<=takenX1; i++)
            for (int j=takenY; j<=takenY1; j++)
                map[i][j].setSubject(subject);
    }
    public void exclude(Subject subject){
        takenX = (subject.getRect().getX()+1)/TILE_SIZE;
        takenX1 = (subject.getRect().getX1()-1)/TILE_SIZE;
        takenY = (subject.getRect().getY()+1)/TILE_SIZE;
        takenY1 = (subject.getRect().getY1()-1)/TILE_SIZE;
        for (int i=takenX; i<=takenX1; i++)
            for (int j=takenY; j<=takenY1; j++)
                map[i][j].exclude(subject);
    }
    public void exclude(Building building){
        for (int i=building.getRect().getX()/TILE_SIZE; i<building.getRect().getX1()/TILE_SIZE; i++)
            for (int j=building.getRect().getY()/TILE_SIZE; j<building.getRect().getY1()/TILE_SIZE; j++)
            { try{map[i][j].exclude(building);} catch (ArrayIndexOutOfBoundsException e){Log.d("MyMap","MyMap Tile excludeSubject "+e);}
                //Log.d("Log","taken "+i+" "+j+" "+b);
            }
        shouldUpdate=true;
    }
    public int isTaken(int x, int y){ try {return map[x/TILE_SIZE][y/TILE_SIZE].quanSubjects();} catch (ArrayIndexOutOfBoundsException e){return -9999;}}
    public Subject isEnemy(int x, int y, int team){ try{return map[x/TILE_SIZE][y/TILE_SIZE].isEnemy(team);} catch (ArrayIndexOutOfBoundsException e){} return null;}
    public Building getBuilding(int x, int y){ try {return map[x/TILE_SIZE][y/TILE_SIZE].getBuilding();} catch (ArrayIndexOutOfBoundsException e){return null;}}
    public Squad getSquad(int x, int y, int team){ return (map[x/TILE_SIZE][y/TILE_SIZE].getAlly(team)).getSquad();}
    public Squad getSquad(int a){ try{ return squads.get(a);} catch (IndexOutOfBoundsException e){return null;}}
    public boolean canControl(int x, int y,int team){ try{return map[x/TILE_SIZE][y/TILE_SIZE].canControl(team);}catch (ArrayIndexOutOfBoundsException e){} return false;}
    public int getDefenceBonus(int x, int y){ return map[x/TILE_SIZE][y/TILE_SIZE].getDefenceBonus();}
    public int getSpeedBonus(int x, int y){ return map[x/TILE_SIZE][y/TILE_SIZE].getSpeedBonus();}


    public ArrayList<Building> buildings;
    public ArrayList<Squad> squads;
    public ArrayList<Squad>[][] zoneSquads;
    HashMap dd;

    protected Tile map[][];

    public  MyMap() {
        inSearch = new boolean[200][200];
        for (int i=0; i<200; i++)
            for (int j=0; j<200; j++)
                inSearch[i][j]=false;
        squads = new ArrayList<>();
        buildings = new ArrayList<>();


        Log.d("Log", " buildings length is " + buildings.size());
        Log.d("Log", " subjects length is " + squads.size());

    }
    void destroy(Building building){
        for (int i=building.getId(); i<buildings.size(); i++)
            buildings.get(i).changeId(-1);
        exclude(building);
        buildings.remove(building);

    }
    void addBuilding(Building building){
        try{ destroy(map[building.getRect().getX() / TILE_SIZE][building.getRect().getY() / TILE_SIZE].getBuilding());} catch (Exception e){}
          try{  destroy(map[(building.getRect().getX1() - 1) / TILE_SIZE][building.getRect().getY() / TILE_SIZE].getBuilding()); } catch (Exception e){}
        try{destroy(map[building.getRect().getX() / TILE_SIZE][(building.getRect().getY1()-1) / TILE_SIZE].getBuilding()); } catch (Exception e){}
          try{  destroy(map[(building.getRect().getX1()-1) / TILE_SIZE][(building.getRect().getY1()-1) / TILE_SIZE].getBuilding()); } catch (Exception e){}
        try{destroy(map[building.getRect().getCenterX() / TILE_SIZE][building.getRect().getCenterY() / TILE_SIZE].getBuilding()); } catch (Exception e){}

        building.setMap(this);
        if (building instanceof Portal) ((Portal) building).setFront('l');
        try{
            setEngaged(building);
        } catch (Exception e) { return;}
        buildings.add(building);
        building.setId(buildings.size());
    }
    public Building getLastB(){
        return buildings.get(buildings.size()-1);
    }
    public Squad getLastS(){
        return squads.get(squads.size()-1);
    }

static int side = 60;
    int sideT = side/TILE_SIZE;
    void addBuilding(int x, int y, int x1, int y1, String type, int team) {
        switch (type){
            case "wall": for (int i = x; i <= x1; i += side) {addBuilding(new Wall(i,y,team)); addBuilding(new Wall(i, y1, team));
            }
                for (int i=y+side; i < y1; i += side){ addBuilding(new Wall(x,i,team)); addBuilding(new Wall(x1,i,team));}
        break;
            case "simpleTower": for (int i=x; i <= x1; i += side) {
                addBuilding(new SimpleTower(x,y,team)); addBuilding(new SimpleTower(x, y1, team));}
                for (int i = y + side; i < y1; i += side) {
                addBuilding(new SimpleTower(x,i,team)); addBuilding(new SimpleTower(x1,i,team));}
                break;
            case "portal": for (int i = x; i <= x1; i += side) {addBuilding(new Portal(x,y,team)); addBuilding(new Portal(x,y1,team));}
                for (int i = y + side; i < y1; i+=side){ addBuilding(new Portal(x,i,team)); addBuilding(new Portal(x1,i,team));}
                break;
        }
    }
    void addSquad(Squad squad){squads.add(squad);
    engine.myView.add(squad);}
    public void addTile(Tile tile){
        Log.d("MyMap","probably Decoder adding tile"+tile.rect.getX()/TILE_SIZE+" "+tile.rect.getY()/TILE_SIZE);
try{  map[tile.rect.getX()/TILE_SIZE][tile.rect.getY()/TILE_SIZE] = tile;} catch (NullPointerException e) {
} catch (ArrayIndexOutOfBoundsException e){
}
    }
    void addTile( int x, int y, int x1, int y1,String tile){
Log.d("MyMap","addTile "+x+" "+y+" "+x1+" "+y1+" "+tile);
        switch (tile){
            case "tile":for (int i=x; i<=x1; i++) for (int j=y; j<=y1; j++){map[i][j]=new Tile(i,j,this);} break;
            case "water":for (int i=x; i<=x1; i++) for (int j=y; j<=y1; j++){map[i][j]=new Water(i,j,this); } break;
            case "road":for (int i=x; i<=x1; i++) for (int j=y; j<=y1; j++){map[i][j]=new Road(i,j,this); } break;
        }
    }
    void addTile( int x, int y,String tile) {
        Log.d("MyMap", "addTile " + x + " " + y + " " + tile);
        switch (tile) {
            case "tile": {
                map[x][y] = new Tile(x, y, this);
            }
            break;
            case "water":
                map[x][y] = new Water(x, y, this);
                break;
            case "road":
                map[x][y] = new Road(x, y, this);
                break;
        }
    }
    int SquadSize=9;
    String SquadType ;
    public void setSize(int w, int h){W=w; H=h; map = new Tile[W][H];
        zoneSquads = new ArrayList[W/zoneSide+1][H/zoneSide+1]; //there must be a better way
        for (int i=0; i<W/zoneSide+1; i++)
            for (int j=0; j<H/zoneSide+1; j++)
                zoneSquads[i][j]=new ArrayList<>();
        Log.d("Log", " zoneSquad  " +(W/zoneSide+1)+" "+(H/zoneSide+1));
    }
    public void addBuilding(Engine engine,int x,int y){ Log.d("Log", "MyMap adding building " + x + " " + y); engine.addBuilding(x,y); }

    public void fill(Renderer renderer){

        if (MapEditor.W==0||MapEditor.H==0)
        decoder.loadMap(this, MapChoose.map);else {
            setSize(MapEditor.W,MapEditor.H);
            decoder.newMap("map",this);
            decoder.loadMap(this);
        }
        for (int i=0; i<map.length; i++)
            for (int j=0; j<map[0].length; j++)
                Log.d("MyMap","filled new map "+map[i][j]);

        Log.d("Log", "map generated "+map.length+" "+map[0].length);
       // squads.add(new Squad(300,300,"warrior",10,this));
        for (int i=0; i<squads.size(); i++) {squads.get(i).setId(i);
           // engine.addSquadButton(squads.get(i),i);
            }

        Log.d("Log", "MyMap fill " + squads.size() + " squads");
       optimize(renderer);
    }

Decoder decoder;
    public void setDecoder(Decoder decoder){ this.decoder = decoder;}



    void optimize(Renderer renderer){

        int d=1;
        do{
            d*=2;
            for (int i = 0; i < W; i += d)
                for (int j = 0; j < H; j += d)
                    try {
                        ((CanvasRenderer) renderer).band2(map[i][j], map[i + d / 2][j], map[i][j + d / 2], map[i + d / 2][j + d / 2], d);
                    } catch (ArrayIndexOutOfBoundsException e) {
                    }

        } while (d<1024);
      //  ((CanvasRenderer) renderer).cleanUp(d/2);
        ((CanvasRenderer) renderer).setHash();
        for (int i = 0; i < W; i ++)
            for (int j = 0; j < H; j ++) {

                if (map[i][j].shouldDraw) {
                    map[i][j].setName(map[i][j].name.hashCode());
                    map[i][j].setName(map[i][j].hash + "");
                    //Log.d("MyMap","setHash "+map[i][j].name+"\n"+map[i][j].hash);
                }

            }
        for (int i=0; i<W; i++)
            for (int j = 0; j < H; j ++){

            }

    }







    void draw(Renderer renderer, double k){
for (int i=0; i<W; i++)
    for (int j=0; j<H; j++){
            map[i][j].draw(renderer,k);


            }

        for (int i=0; i<squads.size(); i++)try{ squads.get(i).draw(renderer); } catch (Exception e){}
        for (int i=0; i<buildings.size(); i++)try{ buildings.get(i).draw(renderer); } catch (Exception e){}


/*
        for (int i=0; i<W; i++)
            for (int j=0; j<H; j++)
                if (inSearch[i][j]) renderer.drawRect(i*TILE_SIZE,j*TILE_SIZE,i*TILE_SIZE+TILE_SIZE,j*TILE_SIZE+TILE_SIZE,0xFF2222AA);
*/
    }
    public void destroy(int i){
        Log.d("MyMap","destroying "+i);
        exclude(buildings.get(i));
        buildings.remove(i);

    }
    void update(Renderer renderer, int time){
        for (int i=0;i<buildings.size();i++) {if (!buildings.get(i).upd()) destroy(i);}
        for (int i=0;i<squads.size();i++) squads.get(i).update(renderer, time);
    }

    public Squad getClosest(int left,int top, int right, int bottom, int team){ //Enemy
        Log.d("MyMap","Squad get closest "+left+" "+top+" "+right+" "+bottom+" "+team);
        int min=Integer.MAX_VALUE;
        int temp;
        Squad enemy=null;
        for (Squad susp : zoneSquads[left/TILE_SIZE/zoneSide][top/TILE_SIZE/zoneSide]) {
            if (susp.getTeam() != team)
                if ((temp=pif(susp.right,susp.bottom,left,top))<min)
                {min=temp; enemy=susp;}
        }
        if (min<TILE_SIZE) return enemy;
        for (Squad susp : zoneSquads[left/TILE_SIZE/zoneSide][bottom/TILE_SIZE/zoneSide]) {
            if (susp.getTeam() != team)
                if ((temp=pif(susp.right,susp.top,left,bottom))<min)
                {min=temp; enemy=susp;}
        }
        if (min<TILE_SIZE) return enemy;
        for (Squad susp : zoneSquads[right/TILE_SIZE/zoneSide][top/TILE_SIZE/zoneSide]) {
            if (susp.getTeam() != team)
                if ((temp=pif(susp.left,susp.bottom,right,top))<min)
                {min=temp; enemy=susp;}
        }
        if (min<TILE_SIZE) return enemy;
        for (Squad susp : zoneSquads[right/TILE_SIZE/zoneSide][bottom/TILE_SIZE/zoneSide]) {
            if (susp.getTeam() != team)
                if ((temp=pif(susp.left,susp.top,right,bottom))<min)
                {min=temp; enemy=susp;}
        }

         return enemy;

    }
    public int pif(int x, int y, int x1, int y1){
        return ((x-x1)*(x-x1)+(y-y1)*(y-y1));
    }




}
