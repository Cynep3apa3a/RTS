package com.example.dmitry.rts.Objects.Buildings;

import android.util.Log;

import com.example.dmitry.rts.Decoder;
import com.example.dmitry.rts.MyMap;
import com.example.dmitry.rts.Rectangle;

/**
 * Created by Dmitry on 26.12.2015.
 */
public class Wall extends Building {
    public Wall(int x, int y, int team) {
            super(x, y, team);
            h=60;
            w=60;
            hp=500;
            rect=new Rectangle(x,y,x+w,y+h);
        num=1;
    }
}
