package com.example.dmitry.rts;

import java.io.Serializable;

/**
 * Created by Dmitry on 11.01.2016.
 */
public class Rectangle implements Serializable{

    public int getX() {
        return x;
    }
    public int getY() {return y;}
    public int getX1() {
        return x1;
    }
    public int getY1() {
        return y1;
    }
    public int getCenterX() {return (x1+x)/2+(x1+x)%2;}
    public int getCenterY() {return (y1+y)/2+(y1+y)%2;}
    public int getWidth() {return x1-x;}
    public int getHeight() {return y1-y;}
    public Rectangle getScaled( double k){return new Rectangle((int)Math.round(x*k),(int)Math.round(y*k),(int)Math.round(x1*k),(int)Math.round(y1*k));}

    public Rectangle divide(int k){ return new Rectangle((x/k),(y/k),(x1/k),(y1/k));}
    public boolean isSame(Rectangle rect){if (rect.getX()==x&&rect.getY()==y&&rect.getX1()==x1&&rect.getY1()==y1) return true; return false;}
    public boolean isIn(int x,int y) {if (x>this.x&&x<x1&&y>this.y&&y<y1) return true; else return false;}
    public boolean isIn(Point point) {if (point.getX()<x1&&point.getX()>x&&point.getY()<y1&&point.getY()>y) return true; else return false;}
    private int x,y,x1,y1;
       public Rectangle(int x,int y,int x1,int y1){
            this.x=x;
            this.y=y;
            this.x1=x1;
            this.y1=y1;
        }
    public Rectangle(Point p,Point p2){
        this.x=p.getX();
        this.y=p.getY();
        this.x1=p2.getX();
        this.y1=p2.getY();
    }
    public Rectangle(Point p,int w, int h){
        this.x=p.getX();
        this.y=p.getY();
        this.x1=p.getX()+w;
        this.y1=p.getY()+h;
    }
   public void move(int a,int b){
       x+=a; x1+=a;
       y+=b; y1+=b;
    }
    public double pif(int a,int b){
        return ((getCenterX()-a)*(getCenterX()-a)+(getCenterY()-b)*(getCenterY()-b));
    }
    public void scaleScreen(double k){x1/=k; y1/=k;}
    public void multipyThis(Point p){ x*=p.getX(); x1*=p.getX(); y*=p.getY(); y1*=p.getY();}
    public Rectangle multipy(int k){ return new Rectangle(x*=k, x1*=k, y*=k, y1*=k);}
    public Rectangle minus(int k){ return new Rectangle(x-=k, x1-=k, y-=k, y1-=k);}
    public Rectangle minus(Point k){ return new Rectangle(x-=k.getX(), x1-=k.getX(), y-=k.getY(), y1-=k.getY());}






}
