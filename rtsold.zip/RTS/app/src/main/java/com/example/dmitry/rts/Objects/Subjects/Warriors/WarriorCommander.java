package com.example.dmitry.rts.Objects.Subjects.Warriors;


import com.example.dmitry.rts.Behaviors.PathSearch.Search;
import com.example.dmitry.rts.MyMap;
import com.example.dmitry.rts.Objects.Subjects.Commander;
import com.example.dmitry.rts.Objects.Subjects.Squad;
import com.example.dmitry.rts.Point;
import com.example.dmitry.rts.Rectangle;

/**
 * Created by Dmitry on 24.01.2016.
 */
public class WarriorCommander extends Commander {
    public WarriorCommander(int id, MyMap myMap) {
        super(id,myMap );
        vel = 1;
        w=20;
        h=20;
        HP=hp=10;
        atcDist=1;
        atc=1;
        reload = 45;
    }
    public WarriorCommander(int id, MyMap myMap, int hp,Rectangle rect, Point position, Point absPosition,Squad squad) {
        super(id,myMap,hp,rect,position,absPosition,squad);
        search = new Search(myMap);
        tile = search.getTileSize();
        this.myMap = myMap;
        this.hp=hp;
        this.rect=rect;
        this.position=position;
        this.absolutePos=absPosition;
        mySquad=squad;
        setName();
        setTarget(rect.getCenterX(), rect.getCenterY());

    }

}
