package com.example.dmitry.rts.Objects.Buildings;

import android.graphics.Bitmap;
import android.util.Log;

import com.example.dmitry.rts.MyMap;

import com.example.dmitry.rts.Rectangle;
import com.example.dmitry.rts.Renderer;

import java.io.Serializable;
import java.util.Arrays;

/**
 * Created by Dmitry on 11.12.2015.
 */
public class Building implements Serializable{
    int x;
    int y;
    int HP;
    int hp;
    int w;
    int h;
    int id;
    int team;
    int atc,atcX,atcY,atcDist;
    Bitmap img;
    transient MyMap myMap;
    int num=1;
    public boolean[] engaged;
    public int friend=0;


    public void attacked(int atc){ hp-=atc; Log.d("Building","attacked :"+hp+" atc "+atc);}
    public Rectangle getRect() {
        return rect;
    }

    transient Rectangle rect;
    public void setTeam(int team){this.team = team;}

    public int getTeam(){ return team;}

    public int getMinX(int a){ if (a>=rect.getX()&&a<=rect.getX1()) return a; else if (a<rect.getX()) return rect.getX(); else return rect.getX1();}
    public int getMinY(int a) {if (a>=rect.getY()&&a<=rect.getY1()) return a; else if (a<rect.getY())return rect.getY(); else return rect.getY1();}
    protected String name;
    void setName(){name = getClass().getSimpleName().toLowerCase();}
    public void setName(String s){name =  s.toLowerCase();}
    public void addName(String s){name += s.toLowerCase();}
    public String getName(){return name;}


    public Building(int x,int y, int team){
        this.x=x;
        this.y=y;
        rect = new Rectangle(x,y,x+w,y+h);
        setName();
        }
   public void setId(int id){this.id = id; HP=hp;}
   public  void draw(Renderer renderer) {
       renderer.drawBuilding(name,rect);
      // renderer.drawText((int)((hp+0.0)/HP*100)+"%",rect.getCenterX()-7,rect.getCenterY());
    //   renderer.drawText(x+" "+y,x+2,y+8);
   }
    public boolean upd(){
        return hp>0;
      //  if (hp<=0) destroyMe();
      //  if (hp<HP*0.1) burnMe();
    }
    public void setMap(MyMap map){
        this.myMap=map;
    engaged = new boolean[w/myMap.getTILE_SIZE()*h/myMap.getTILE_SIZE()];
        Arrays.fill(engaged,true);}
   /* void destroyMe(){
        myMap.destroy(this);
    }*/
    void burnMe(){}
   public void changeId(int a){id+=a;}
    void atc(int x, int y){}
    public int getId(){return id;}
}
