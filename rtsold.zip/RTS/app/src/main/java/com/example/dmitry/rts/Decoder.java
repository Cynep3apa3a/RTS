package com.example.dmitry.rts;

import android.content.ContentValues;
import android.content.Context;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Environment;
import android.util.Log;
import android.util.Xml;


import com.example.dmitry.rts.Objects.Buildings.Building;
import com.example.dmitry.rts.Objects.Subjects.Squad;
import com.example.dmitry.rts.Objects.Tiles.Tile;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by Dmitry on 20.12.2015.
 */
public class Decoder {
    Context context;
    public void setContext(Context context){
        this.context = context;
    }

    public Decoder() {
        Log.d("Decoder","*****  New Decoder *****");
    }




    public Bitmap getImg(String name){
        Bitmap img = null;
        Log.d("Decoder","decoding getImg "+ name);
        AssetManager manager = context.getAssets();
        try {
            img= BitmapFactory.decodeStream(manager.open(name));
        } catch (IOException e) {
            try{img= BitmapFactory.decodeStream(manager.open("Tiles/"+name+".png"));} catch (IOException e1) {
                Log.d("Decoder", "decoder getImg " + e1);
            }

        }
        return img;
    }

    public Bitmap getMapThumb(String s, int w, int h){
        if (w==0) w=64;
        if (h==0) h=64;
        return Bitmap.createScaledBitmap(getImg("Maps/Thumb/"+s.toLowerCase()+".png"),w,h,true);
    }





    void loadMap(MyMap myMap, int id) {
        if (id==-9) {loadMap(myMap); return;}
try {


    XmlPullParser parser = context.getResources().getXml(id);
    while (parser.getEventType() != XmlPullParser.END_DOCUMENT) {
        if (parser.getEventType() == XmlPullParser.START_TAG) {
            Log.d("Decoder", parser.getName());
            switch (parser.getName()) {
                case "size":
                    myMap.setSize(Integer.parseInt(parser.getAttributeValue(0)),Integer.parseInt(parser.getAttributeValue(1)));
                    break;
                case "building":
                    myMap.addBuilding(Integer.parseInt(parser.getAttributeValue(0)), Integer.parseInt(parser.getAttributeValue(1)), Integer.parseInt(parser.getAttributeValue(2)), Integer.parseInt(parser.getAttributeValue(3)), parser.getAttributeValue(4), Integer.parseInt(parser.getAttributeValue(5)) );
                    //myMap.addBuilding(new Wall(Integer.parseInt(parser.getAttributeValue(0)), Integer.parseInt(parser.getAttributeValue(1)), Integer.parseInt(parser.getAttributeValue(2)) ));
                    break;
                case "squad":
                   myMap.addSquad(new Squad(Integer.parseInt(parser.getAttributeValue(0)), Integer.parseInt(parser.getAttributeValue(1)), parser.getAttributeValue(2), Integer.parseInt(parser.getAttributeValue(3)), myMap,Integer.parseInt(parser.getAttributeValue(4))));
                    break;
                case "tile": myMap.addTile(Integer.parseInt(parser.getAttributeValue(0)), Integer.parseInt(parser.getAttributeValue(1)), Integer.parseInt(parser.getAttributeValue(2)), Integer.parseInt(parser.getAttributeValue(3)), parser.getAttributeValue(4));
                    break;
            }
        }
        parser.next();
    }
} catch (IOException e){} catch (XmlPullParserException e){}
    }

    void loadMap(MyMap myMap)  {
        if (!mapExists) { Log.d("Decoder","loadMap returning");return;}
        file = new File(context.getFilesDir(),"map");
        Object object;
        try {
          //  if (file==null) newMap("map");
            Log.d("Decoder","loadMap file = "+file+" w "+file.canWrite()+" r "+file.canRead()+" length "+file.length());
            ois = new ObjectInputStream(new FileInputStream(file.getPath()));
           // Log.d("Decoder","ois obj"+ois.readObject());
            while ((object=ois.readObject())!=null){
                Log.d("Decoder","loadMap reading map...");
                if (object instanceof Point) myMap.setSize(((Point) object).getX(),((Point) object).getY());
                if (object instanceof Building) myMap.addBuilding((Building)object);
                if (object instanceof Tile) myMap.addTile((Tile)object);
            }
            ois.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    int id;
    ObjectInputStream ois;
    ObjectOutputStream oos;


    public void setId(int id){this.id=id;}

    public void add(Object object, ObjectOutputStream oos){
        try {
            oos.writeObject(object);
            Log.d("Decoder","writing "+object);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Log.d("Decoder","write "+e);
        } catch (IOException e) {
            e.printStackTrace();
            Log.d("Decoder", "write " + e);
            try {
                oos.flush();
            } catch (IOException e1) {
                e1.printStackTrace();
                Log.d("Decoder", "add flush " + e1);
            }
        }

    }
    File file;
    public void newMap(String name,MyMap myMap) {

        Log.d("Decoder"," newMap started");

        try {
            file = new File(context.getFilesDir(), name);
            oos = new ObjectOutputStream(new FileOutputStream(file));
        } catch (IOException e){}

        try {
            file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
            Log.d("Decoder","createNew "+e);
        }
        Log.d("Decoder","newCreated "+file);
        Log.d("Decoder", "MapEditor W,H " + MapEditor.W + " " + MapEditor.H);
        add(new Point(MapEditor.W,MapEditor.H),oos);
        for (int i=0; i<MapEditor.W; i++)
            for (int j=0; j<MapEditor.H; j++) {
                Log.d("Decoder","going to add new tile "+i+" "+j);
                add(new Tile(i, j, myMap),oos);
            }
        mapReady = true;
        mapExists = true;

    }
    boolean mapReady = false;
    public void save(MyMap myMap, String name) throws IOException {
        file = new File(context.getFilesDir(),name);
        file.createNewFile();
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
        add(new Point(myMap.getW(),myMap.getH()),oos);
        for (int i=0; i<myMap.getW(); i++)
            for (int j=0; j<myMap.getH(); j++)
                add(myMap.getTile(i,j),oos);
        for (int i=0; i<myMap.buildings.size(); i++)
            add(myMap.buildings.get(i),oos);
        for (int i=0; i<myMap.squads.size(); i++)
            add(myMap.squads.get(i),oos);
        mapExists = true;

    }
    public void save(MyMap myMap) throws IOException {
        mapExists = false;
        file = new File(context.getFilesDir(),"map");
        file.createNewFile();
        add(new Point(myMap.getW(), myMap.getH()), oos);
        for (int i=0; i<myMap.getW(); i++)
            for (int j=0; j<myMap.getH(); j++)
                add(myMap.getTile(i,j),oos);
        for (int i=0; i<myMap.buildings.size(); i++)
            add(myMap.buildings.get(i),oos);
        for (int i=0; i<myMap.squads.size(); i++)
            add(myMap.squads.get(i),oos);
        mapExists = true;
        Log.d("Decoder","Map saved");

    }
    public static boolean mapExists = false;



}
