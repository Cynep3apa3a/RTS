package com.example.dmitry.rts.Objects.Buildings;


import com.example.dmitry.rts.Rectangle;

/**
 * Created by Dmitry on 28.12.2015.
 */
public class SimpleTower extends Building {
    boolean atacked=false;
    public SimpleTower(int x, int y, int team) {
        super(x, y,team);
        h=60;
        w=60;
        hp=100;
        atcDist=50;
        atc=1;
        rect=new Rectangle(x,y,x+w,y+h);

    }
    int wait=0;
    int atcId;
    @Override
    public boolean upd(){
        for (int i=(rect.getX()-atcDist); i<(rect.getX1()+atcDist); i+=myMap.getTILE_SIZE())
            for (int j=(rect.getY()-atcDist); j<(rect.getY1()+atcDist); j+=myMap.getTILE_SIZE())
                if (!atacked&&wait<=0)
                if (myMap.getTile(i,j).isEngaged()){
                   try{ myMap.getTile(i,j).isEnemy(team).looseHp(atc);
                    atacked=true; num=2;  wait=60; } catch (NullPointerException e){}
                }
        if (wait==50) num=1;
        if (wait<=0) {atacked=false; wait=0;}
        if (atacked) wait--;
        return hp>0;
    }
    @Override
    void atc(int x, int y){

    }
}
