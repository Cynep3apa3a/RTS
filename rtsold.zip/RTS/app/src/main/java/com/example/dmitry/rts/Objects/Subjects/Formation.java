package com.example.dmitry.rts.Objects.Subjects;

import com.example.dmitry.rts.Point;
import com.example.dmitry.rts.Rectangle;

import java.lang.Math;

/**
 * Created by Dmitry on 24.01.2016.
 */
public class Formation {
    private Point[] sq;
private  int left,right,top,bottom;
    public int getLeft(){return left;}
    public int getRight(){return right;}
    public int getBottom(){return bottom;}
    public int getTop(){return top;}
Squad squad;
    public Formation(Squad squad){
        this.squad = squad;
    }

    public Point[] getFormation(String type,int n){
        sq = new Point[n];
        switch (type) {
            case("square"): for (int i=0; i<n; i++) sq[i]=square(n,i);
        }
        return sq;
    }
     public Point square(int n, int a){ //n - size; a - soldier number;
        int side = (int)Math.sqrt(n);
         left=0; top=0;
         bottom=(int)Math.round(Math.sqrt(n)-1); right=side-1;
        return new Point(a%side,a/side);

    }
    public Point rectangle(int side, int a){ //n - size; a - soldier number;
       // if (squad.length%side!=0) extraOne=-1;
        left=top=0;
        bottom=a/side; right=side-1;
        return new Point(a%side,a/side);
    }
    int extraOne=0;
    public Point pincer(int side, int a){
        left=-Math.min(side*3/5,squad.length/side);
        right = side-1;
        extraOne=0;
        if (squad.length%side>Math.min(side*3/5,squad.length/side)) extraOne=1;

        bottom =squad.length/side+extraOne-1;
        top=0;
if (true) {
    if (a < side * 2) return new Point(a % side + Math.min(side*3/5,squad.length/side), a / side);
    if (a >= squad.length - side * 2)
        return new Point((squad.length - a-1) % side + Math.min(side*3/5,squad.length/side), (squad.length - a-1) / side + side + extraOne);

    return new Point(a % side, a / side);
}
        return new Point(1, a );
    }

    int i=0,j=0;
    public Point pig(int n, int a){ //n - size; a - soldier number;
        int x;
        if (i>j) {j++; i=0;}
        i++;
        int imax = ((int)Math.sqrt(1+8*n)-1)/2;
        Point point = new Point(i/imax,j);
        if (n==a+1) i=1;
        return point;
    }
}
