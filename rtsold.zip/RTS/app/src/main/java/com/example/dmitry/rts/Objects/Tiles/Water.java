package com.example.dmitry.rts.Objects.Tiles;


import com.example.dmitry.rts.MyMap;

/**
 * Created by Dmitry on 25.02.2016.
 */
public class Water extends Tile {
    public Water(int x, int y, MyMap myMap) {
        super(x, y, myMap);

    }
}
