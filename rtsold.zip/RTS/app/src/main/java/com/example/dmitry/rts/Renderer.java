package com.example.dmitry.rts;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

import com.example.dmitry.rts.Objects.Subjects.Subject;

import java.util.ArrayList;

/**
 * Created by Dmitry on 11.01.2016.
 */
public abstract class Renderer extends Thread{
    public abstract void drawText(String text, int x, int y);
    public abstract void drawText(String text, int x, int y, int color);

    public abstract void drawImg(String name,Rectangle rect,int ang, int x);
    public abstract void drawBuilding(String name,Rectangle rect);
    public abstract void drawTile(String name,Rectangle rect, int param);
    public abstract void drawTile(int name,Rectangle rect, int param);

    public abstract void drawRect(float x, float y, float x1, float y1, int color);
    public abstract void drawChosen(Rectangle rect, int color);
    public abstract void resize(double k);
    public abstract void setCanvas(Canvas canvas);
    //public abstract double getK();
    public abstract void setDecoder(Decoder decoder);
    public  abstract Decoder getDecoder();

    public abstract void setScreen(Rectangle screen);
    public abstract void moveScreen(int a, int b); //moving screen
    public abstract Point move(Rectangle rect,int x, int y); //collider
    public abstract void setMyMap(MyMap myMap);
    public abstract void drawHpOval(Rectangle rect, int HP, int hp);
    public abstract void drawLine(Point a, Point b);
    public abstract void drawButton(String name,Rectangle rect, int state);

}
