package com.example.dmitry.rts.Objects.Subjects;

import android.util.Log;

import com.example.dmitry.rts.Behaviors.PathSearch.Search;
import com.example.dmitry.rts.MyMap;
import com.example.dmitry.rts.Objects.Buildings.Building;
import com.example.dmitry.rts.Point;
import com.example.dmitry.rts.Rectangle;
import com.example.dmitry.rts.Renderer;

/**
 * Created by Dmitry on 24.01.2016.
 */
public class Commander extends Subject {
    protected Search search;
    protected int targetX,targetY;
    protected Point tempTarget;
    protected int tile;
    protected int vel;
    protected MyMap myMap;
    public Commander(int id, MyMap myMap) {
        super(id,myMap);
        search = new Search(myMap);
        tile = search.getTileSize();
        this.myMap = myMap;
        setName();

    }
    public Commander(int id, MyMap myMap, int hp,Rectangle rect, Point position, Point absPosition,Squad squad){
        super(id,myMap);
        search = new Search(myMap);
        tile = search.getTileSize();
        this.myMap = myMap;
        this.hp=hp;
        this.rect=rect;
        this.position=position;
        this.absolutePos=absPosition;
        mySquad=squad;
        setName();
        setTarget(rect.getCenterX(), rect.getCenterY());

    }
    @Override
    void findWay(){
        search.findWay(rect.getX() + w / 2, rect.getY() + h / 2, targetX, targetY, rect);
        shouldGo=true;
    }
    @Override
    public void setRect(int x, int y){
        rect = new Rectangle(x-w/2,y-w/2,x+w/2+w%2,y+h/2+h%2);
        setTarget(x, y); tempTarget=new Point(x,y);

    }
   @Override
    public void setTarget(int x, int y){
       Log.d("Commander",id+" setTarget "+x+" "+y);
        targetX=x; targetY=y;
        findWay();
        askNextPoint();
       }
    @Override
    public void update(Renderer renderer, int time){
        if (hp<=0) {mySquad.destroyMe(this); return;}
       // Log.d("Commander",hp+" "+myMap+" "+rect);
        myMap.getDefenceBonus(rect.getCenterX(),rect.getCenterY());
        myMap.exclude(this);
         go(renderer);
        myMap.setTaken(this);
       // if (!attacking) if (time==id) passiveCheck();

    }
    void alert(Subject subject){
        mySquad.rotate((int)Math.toDegrees(Math.atan2(subject.getRect().getY()/rect.getY(),subject.getRect().getX()/rect.getX())));
    }
    void askNextPoint() {

            tempTarget = search.getNextPoint();
            if (tempTarget.getX()<0) {

                tempTarget=new Point(targetX,targetY);
                if (mySquad.targetSquad!=null) {
                checkSurroundings(mySquad.targetSquad);
                 } else
                if (mySquad.targetBuilding!=null) {
                    checkSurroundings(mySquad.targetBuilding);
                }
            }
         }
    void calcTxTy(){
        if (rect.getCenterX() < tempTarget.getX()) tx = 1;
        else if (rect.getCenterX() > tempTarget.getX()) tx = -1;
        if (rect.getCenterY() < tempTarget.getY()) ty = 1;
        else if (rect.getCenterY() > tempTarget.getY()) ty = -1;
    }

    void checkSurroundings(Squad squad){

    }
    void checkSurroundings(Building building){

    }

    boolean shouldGo=true;

    @Override
    public void go(Renderer renderer){
       // Log.d("Commander","going to target "+targetX+" "+targetY+" temp "+tempTarget.getX()+" "+tempTarget.getY());
        speedBonus=myMap.getSpeedBonus(rect.getCenterX(),rect.getCenterY());
        if (shouldGo) {
            //  Log.d("Log","Commander target "+targetX+" "+targetY+" rect"+rect.getX()+" "+rect.getY());
            if (targetX != rect.getCenterX() || targetY != rect.getCenterY()) {

                tx = ty = 0;
                calcTxTy();
                if (tx==0&&ty==0) {askNextPoint();go(renderer);}

                else {
                    if (Math.abs(rect.getCenterX() - tempTarget.getX()) <
                            (vel+speedBonus)) tx*=Math.abs(rect.getCenterX() - tempTarget.getX()); else tx *= (vel + speedBonus);

                    if (Math.abs(rect.getCenterY()-tempTarget.getY()) <
                            (vel+speedBonus)) ty*=Math.abs(rect.getCenterY() - tempTarget.getY()); else ty *= (vel + speedBonus);


                    if (tx>10||ty>10||tx<-10||ty<-10) Log.d("Commander",tx+" "+ty+" cx "+(rect.getCenterX())+" cy "+
                            (rect.getCenterY())+" vel "+(vel+speedBonus+" temp "+tempTarget.getX()+" "+tempTarget.getY()));
                    Point movingPoint = renderer.move(rect, tx, ty);  //fix it


                    rect.move(tx*movingPoint.getX(),ty* movingPoint.getY());
                }
            } else {
                shouldGo=false;
            }
        }
    }

}
