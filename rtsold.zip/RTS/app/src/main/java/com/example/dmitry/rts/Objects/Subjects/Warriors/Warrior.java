package com.example.dmitry.rts.Objects.Subjects.Warriors;

import com.example.dmitry.rts.MyMap;
import com.example.dmitry.rts.Objects.Subjects.Commander;
import com.example.dmitry.rts.Objects.Subjects.Subject;

/**
 * Created by Dmitry on 19.01.2016.
 */
public class Warrior extends Subject {
    public Warrior(int id,MyMap myMap) {
        super(id, myMap);
        w=20;
        h=20;
        vel = 1;
        HP=hp=10;
        atcDist=2;
        atc=1;
        reload=45;
    }
}
