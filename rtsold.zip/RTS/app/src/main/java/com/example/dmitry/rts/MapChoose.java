package com.example.dmitry.rts;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.media.Image;
import android.os.Bundle;
import android.os.Message;
import android.telephony.SmsMessage;
import android.text.Layout;
import android.util.AttributeSet;
import android.util.Log;
import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.zip.Inflater;

/**
 * Created by Dmitry on 23.02.2016.
 */
public class MapChoose extends Activity implements AdapterView.OnItemClickListener{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        // MyView myView = new MyView(this);
        //   setContentView(myView);
        setContentView(R.layout.activity_maps);
            ListView listView = (ListView) findViewById(R.id.listView);
            MyAdapter adapter = new MyAdapter(this, R.layout.my_list_layout, R.id.myListText, Arrays.asList(getResources().getStringArray(R.array.maps)) ,1,getLayoutInflater());
        listView.setAdapter(adapter);
            listView.setOnItemClickListener(this);

          //  buttons = (ListView)findViewById(R.id.squadsList);
        layout = (FrameLayout)findViewById(R.id.activity_surface);
    }

FrameLayout layout;
    ListView buttons;
    public static MapChoose mapChoose;
    static MyView myView;
static int map;

    public void onClick(View view){

    }

    public int getMapId(int id){
        switch (id){
            case 0: return R.xml.map_one;
            case 1: return R.xml.map_two;
            case 2: return  R.xml.map_three;
            case 3: return R.xml.map_four;
            case 4: if (Decoder.mapExists) return -9;
        }
        return R.xml.map_one;
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if ((map = getMapId((int)id))==-9);
        mapChoose = this;
        MapEditor.W=0;
        MapEditor.H=0;
        setContentView(R.layout.activity_surface);
        findViewById(R.id.save).setVisibility(View.INVISIBLE);
        findViewById(R.id.pause).setOnClickListener((View.OnClickListener) findViewById(R.id.surfaceView));
        findViewById(R.id.build_aim).setOnClickListener((View.OnClickListener)findViewById(R.id.surfaceView));
        findViewById(R.id.rotate).setOnClickListener((View.OnClickListener)findViewById(R.id.surfaceView));
        findViewById(R.id.formation).setOnClickListener((View.OnClickListener)findViewById(R.id.surfaceView));
        findViewById(R.id.super_power).setOnClickListener((View.OnClickListener) findViewById(R.id.surfaceView));
        findViewById(R.id.squad_list);

        ListView listView = (ListView) findViewById(R.id.squad_list);
        MyAdapter adapterS = new MyAdapter(this, R.layout.my_list_layout, R.id.myListText, Arrays.asList(getResources().getStringArray(R.array.maps)),2,getLayoutInflater());
        listView.setAdapter(adapterS);
        listView.setOnItemClickListener((AdapterView.OnItemClickListener)(findViewById(R.id.surfaceView)));
        myView.setAdapter(adapterS);


        Spinner spinner = (Spinner)findViewById(R.id.spinner);
        ArrayAdapter<?> adapter = ArrayAdapter.createFromResource(this, R.array.menu, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) (findViewById(R.id.surfaceView)));
        SeekBar seekBar = (SeekBar)findViewById(R.id.seekBar);
        seekBar.setMax(10); // <- dont really need this
        seekBar.setProgress(9);
        seekBar.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener) (findViewById(R.id.surfaceView)));
    }

}
