package com.example.dmitry.rts;

import java.io.Serializable;

/**
 * Created by Dmitry on 01.01.2016.
 */
public class Point implements Serializable{
    private int x;
    private int y;
    Point send;

    public int getY() {
        return (int)y;
    }

    public int getX() {
        return (int)x;
    }


    public Point(int x, int y){
        this.x=x;
        this.y=y;
    }
    void move(int x,int y){
        this.x+=x;
        this.y+=y;
    }
    public boolean isSame(Point p){
        return (x==p.getX()&&y==p.getY());
    }

    public Point plus(Point point){
        return new Point(x+point.getX(),y+point.getY());
    }
    public Point plusThis(Point point){x+=point.getX();y+=point.getY(); return this;
    }
    public Point plus(int x, int y){
        return new Point(this.x+x,y+this.y);
    }
    public Point plusThis(int x, int y){this.x+=x; this.y+=y; return this;
    }

    public Point multipy(int k){
        return new Point(k*x,y*k);
    }
    public void multipyThis(int k){ x*=k; y*=k;}
    public Point minus(Point point){
        return new Point(x-point.getX(),y-point.getY());
    }



}
